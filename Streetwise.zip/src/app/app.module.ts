import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule, NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AppComponent} from './app.component';
import { StepperModule, WavesModule, ToastModule, MDBBootstrapModulesPro, SidenavComponent} from 'ng-uikit-pro-standard';
import { HttpClientModule } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AppRoutingModule } from '../app/app-routing.module';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './pages/home/home.component';
import { AboutComponent } from './pages/about/about.component';
import { ContactComponent } from './pages/contact/contact.component';
import { FooterComponent } from './components/footer/footer.component';
import { FaqComponent } from './pages/faq/faq.component'
import { MapsService } from './services/maps.service';
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFirestoreModule } from '@angular/fire/firestore'
import { Angular4PaystackModule } from 'angular4-paystack';
import { ContactFormComponent } from './components/contact-form/contact-form.component';
import { QuoteComponent } from './pages/quote/quote.component';
import { PayComponent } from './pages/pay/pay.component';

@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        HomeComponent,
        AboutComponent,
        ContactComponent,
        FooterComponent,
        SidenavComponent,
        FaqComponent,
        ContactFormComponent,
        QuoteComponent,
        PayComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule,
        StepperModule, WavesModule,
        AngularFireModule.initializeApp(environment.config),
        AngularFireAuthModule,
        AngularFirestoreModule,
        MDBBootstrapModulesPro.forRoot(),
        ToastModule.forRoot(),
        Angular4PaystackModule.forRoot('pk_test_aff83a12bc9631dc681b9ea7f9ce8a9d9ee7969a'),
        ReactiveFormsModule,   
    ],
    providers: [MapsService],
    bootstrap: [AppComponent],
    schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule  {
  
}
