(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/app.component.html":
/*!**************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/app.component.html ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n <!-- <div class=\"col\"> -->\r\n    <app-header></app-header>\r\n      <router-outlet></router-outlet>\r\n    <app-footer></app-footer>\r\n <!-- </div> -->"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/contact-form/contact-form.component.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/contact-form/contact-form.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"u-clearfix u-expanded-width-xl u-palette-2-base u-section-7\" id=\"carousel_8c9f\">\n    <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n      <div class=\"u-clearfix u-expanded-width u-gutter-0 u-layout-wrap u-layout-wrap-1\">\n        <div class=\"u-gutter-0 u-layout\">\n          <div class=\"u-layout-row\">\n            <div class=\"u-size-27\">\n              <div class=\"u-layout-col\">\n                <div class=\"u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1\">\n                  <div class=\"u-container-layout u-valign-middle u-container-layout-1\">\n                    <h2 class=\"u-text u-text-palette-3-base u-text-1\">location</h2>\n                    <p class=\"u-text u-text-2\">Suite 35, Block C, Iyana Ejigbo Shopping Arcade, Ejigbo, Lagos, Nigeria&nbsp;\n                    </p>\n                  </div>\n                </div>\n                <div class=\"u-align-left u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-2\">\n                  <div class=\"u-container-layout u-container-layout-2\">\n                    <h2 class=\"u-text u-text-palette-3-base u-text-3\">follow us</h2>\n                    <div class=\"u-social-icons u-spacing-20 u-social-icons-1\">\n                      <a class=\"u-social-url\" target=\"_blank\" href=\"\"><span class=\"u-icon u-icon-circle u-social-facebook u-social-icon u-icon-1\"><svg class=\"u-svg-link\" preserveAspectRatio=\"xMidYMin slice\" viewBox=\"0 0 112.2 112.2\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-05cd\"></use></svg><svg x=\"0px\" y=\"0px\" viewBox=\"0 0 112.2 112.2\" style=\"enable-background:new 0 0 112.2 112.2;\" xml:space=\"preserve\" id=\"svg-05cd\" class=\"u-svg-content\"><path d=\"M56.1,0C25.1,0,0,25.1,0,56.1c0,31,25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1C112.2,25.1,87.1,0,56.1,0z M71.6,34.3h-8.2c-1.3,0-3.2,0.7-3.2,3.5v7.6h11.3l-1.3,12.9h-10V95H45V58.3h-7.2V45.4H45v-8.3c0-6,2.8-15.3,15.3-15.3l11.2,0V34.3z \"></path></svg></span>\n                      </a>\n                      <a class=\"u-social-url\" target=\"_blank\" href=\"\"><span class=\"u-icon u-icon-circle u-social-icon u-social-twitter u-icon-2\"><svg class=\"u-svg-link\" preserveAspectRatio=\"xMidYMin slice\" viewBox=\"0 0 112.2 112.2\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-ed78\"></use></svg><svg x=\"0px\" y=\"0px\" viewBox=\"0 0 112.2 112.2\" style=\"enable-background:new 0 0 112.2 112.2;\" xml:space=\"preserve\" id=\"svg-ed78\" class=\"u-svg-content\"><path d=\"M56.1,0C25.1,0,0,25.1,0,56.1s25.1,56.1,56.1,56.1s56.1-25.1,56.1-56.1S87.1,0,56.1,0z M83.8,47.3 c0,0.6,0,1.2,0,1.7c0,17.7-13.5,38.2-38.2,38.2c-7.6,0-14.6-2.2-20.6-6c1,0.1,2.1,0.2,3.2,0.2c6.3,0,12.1-2.1,16.7-5.7 c-5.9-0.1-10.8-4-12.5-9.3c0.8,0.2,1.7,0.2,2.5,0.2c1.2,0,2.4-0.2,3.5-0.5c-6.1-1.2-10.8-6.7-10.8-13.1c0-0.1,0-0.1,0-0.2 c1.8,1,3.9,1.6,6.1,1.7c-3.6-2.4-6-6.5-6-11.2c0-2.5,0.7-4.8,1.8-6.7c6.6,8.1,16.5,13.5,27.6,14c-0.2-1-0.3-2-0.3-3.1 c0-7.4,6-13.4,13.4-13.4c3.9,0,7.3,1.6,9.8,4.2c3.1-0.6,5.9-1.7,8.5-3.3c-1,3.1-3.1,5.8-5.9,7.4c2.7-0.3,5.3-1,7.7-2.1 C88.7,43,86.4,45.4,83.8,47.3z\"></path></svg></span>\n                      </a>\n                      <a class=\"u-social-url\" target=\"_blank\" href=\"\"><span class=\"u-icon u-icon-circle u-social-icon u-social-instagram u-icon-3\"><svg class=\"u-svg-link\" preserveAspectRatio=\"xMidYMin slice\" viewBox=\"0 0 112.2 112.2\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-556d\"></use></svg><svg x=\"0px\" y=\"0px\" viewBox=\"0 0 112.2 112.2\" style=\"enable-background:new 0 0 112.2 112.2;\" xml:space=\"preserve\" id=\"svg-556d\" class=\"u-svg-content\"><path d=\"M56.1,0C25.1,0,0,25.1,0,56.1c0,31,25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1C112.2,25.1,87.1,0,56.1,0z M90.6,73.4c0,9.6-7.8,17.5-17.5,17.5H38.6c-9.6,0-17.5-7.9-17.5-17.6V38.8c0-9.6,7.8-17.5,17.5-17.5h34.5c9.6,0,17.5,7.8,17.5,17.5 V73.4z\"></path><path d=\"M73.1,28.9H38.6c-5.4,0-9.9,4.4-9.9,9.9v34.5c0,5.4,4.4,9.9,9.9,9.9h34.5c5.4,0,9.9-4.4,9.9-9.9V38.8 C83,33.4,78.6,28.9,73.1,28.9z M55.9,74C46,74,38,66,38,56.1c0-9.9,8-17.9,17.9-17.9c9.9,0,17.9,8,17.9,17.9 C73.8,66,65.8,74,55.9,74z M74.3,41.9c-2.3,0-4.2-1.9-4.2-4.2s1.9-4.2,4.2-4.2c2.3,0,4.2,1.9,4.2,4.2S76.6,41.9,74.3,41.9z\"></path><path d=\"M55.9,45.8c-5.7,0-10.4,4.6-10.3,10.3c0,5.7,4.6,10.3,10.3,10.3s10.3-4.6,10.3-10.3 C66.2,50.4,61.6,45.8,55.9,45.8z\"></path></svg></span>\n                      </a>\n                      <a class=\"u-social-url\" target=\"_blank\" href=\"\"><span class=\"u-icon u-icon-circle u-social-google u-social-icon u-icon-4\"><svg class=\"u-svg-link\" preserveAspectRatio=\"xMidYMin slice\" viewBox=\"0 0 112.2 112.2\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-af15\"></use></svg><svg x=\"0px\" y=\"0px\" viewBox=\"0 0 112.2 112.2\" style=\"enable-background:new 0 0 112.2 112.2;\" xml:space=\"preserve\" id=\"svg-af15\" class=\"u-svg-content\"><path d=\"M56.1,0C25.1,0,0,25.1,0,56.1s25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1S87.1,0,56.1,0z M60.1,73.8 c-5.7,7.4-16.3,9.5-24.9,6.6c-9.1-3-15.8-12.2-15.6-21.9c-0.5-11.9,10-22.9,21.9-23.1c6.1-0.5,12,1.8,16.6,5.7 c-1.9,2.1-3.8,4.1-5.9,6.1c-4.1-2.5-8.9-4.3-13.7-2.7c-7.6,2.2-12.3,11.2-9.4,18.7c2.3,7.8,11.8,12.1,19.3,8.8 c3.9-1.4,6.4-4.9,7.5-8.8c-4.4-0.1-8.8,0-13.3-0.2c0-2.6,0-5.2,0-7.9c7.4,0,14.7,0,22.1,0C65.2,61.8,64.2,68.7,60.1,73.8z M92.3,61.9c-2.2,0-4.4,0-6.6,0c0,2.2,0,4.4,0,6.6c-2.2,0-4.4,0-6.6,0c0-2.2,0-4.4,0-6.6c-2.2,0-4.4,0-6.6,0c0-2.2,0-4.4,0-6.6 c2.2,0,4.4,0,6.6,0c0-2.2,0-4.4,0.1-6.6c2.2,0,4.4,0,6.6,0c0,2.2,0,4.4,0,6.6c2.2,0,4.4,0,6.6,0C92.3,57.5,92.3,59.7,92.3,61.9z\"></path></svg></span>\n                      </a>\n                    </div>\n                    <p class=\"u-text u-text-4\">©2021 Privacy policy</p>\n                  </div>\n                </div>\n              </div>\n            </div>\n            <div class=\"u-size-33\">\n              <div class=\"u-layout-row\">\n                <div class=\"u-container-style u-layout-cell u-right-cell u-size-60 u-layout-cell-3\">\n                  <div class=\"u-container-layout u-container-layout-3\">\n                    <h2 class=\"u-text u-text-palette-3-base u-text-5\">contact form</h2>\n                    <div class=\"u-form u-form-1\">\n                      <form action=\"#\" method=\"POST\" class=\"u-clearfix u-form-spacing-10 u-form-vertical u-inner-form\" style=\"padding: 6px;\" source=\"custom\" name=\"form\">\n                        <div class=\"u-form-group u-form-name\">\n                          <label for=\"name-0bab\" class=\"u-form-control-hidden u-label\">Name</label>\n                          <input type=\"text\" placeholder=\"Enter your Name\" [(ngModel)]=\"name\" id=\"name-0bab\" name=\"name\" class=\"u-border-1 u-border-grey-30 u-input u-input-rectangle u-white\" required=\"\">\n                        </div>\n                        <div class=\"u-form-email u-form-group\">\n                          <label for=\"email-0bab\" class=\"u-form-control-hidden u-label\">Email</label>\n                          <input type=\"email\" placeholder=\"Enter a valid email address\" [(ngModel)]=\"email\" id=\"email-0bab\" name=\"email\" class=\"u-border-1 u-border-grey-30 u-input u-input-rectangle u-white\" required=\"\">\n                        </div>\n                        <div class=\"u-form-group u-form-message\">\n                          <label for=\"message-0bab\" class=\"u-form-control-hidden u-label\">Message</label>\n                          <textarea placeholder=\"Enter your message\" rows=\"4\" cols=\"50\" [(ngModel)]=\"message\" id=\"message-0bab\" name=\"message\" class=\"u-border-1 u-border-grey-30 u-input u-input-rectangle u-white\" required=\"\"></textarea>\n                        </div>\n                        <div class=\"u-align-left u-form-group u-form-submit\">\n                            <a *ngIf=\"!loading\" (click)=\"submit(name, email, message)\" class=\"u-active-white u-btn u-btn-submit u-button-style u-hover-white u-palette-3-base u-text-palette-2-base u-btn-1 shadow\">\n                                     Submit\n                            </a>\n                            <img *ngIf=\"loading\" src=\"../../../assets/images/loader.gif\" style=\"height: 30px; margin: auto;\">\n\n                            <input type=\"submit\" value=\"submit\" class=\"u-form-control-hidden\">\n                        </div>\n                        \n                        <div  *ngIf=\"success\" class=\"u-form-send-message u-form-send-success\"> Thank you! Your message has been sent. We will get back to you shortly</div>\n                        <!-- <div class=\"u-form-send-error u-form-send-message\"> Unable to send your message. Please Ensure you fill all fields. </div>\n                        <input type=\"hidden\" value=\"\" name=\"recaptchaResponse\"> -->\n                      </form>\n                    </div>\n                  </div>\n                </div>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/footer/footer.component.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/footer/footer.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<footer class=\"u-align-center u-clearfix u-footer u-palette-2-base u-footer\" id=\"sec-65a7\"><div class=\"u-clearfix u-sheet u-sheet-1\">\n    <p class=\"u-small-text u-text u-text-variant u-text-1\">Home | About Us | Get A Quote | Track Shipment | Contact Us</p>\n  </div></footer>\n<section class=\"u-backlink u-clearfix u-grey-80\">\n  <p class=\"u-text\">\n    <span>Designed and Developed by &nbsp;</span>\n  </p>\n  <a class=\"u-link\" href=\"https://thumbs-devs.web.app\" target=\"_blank\">\n    <span>Thumbs Developers</span>\n  </a>. \n</section>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/components/header/header.component.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/components/header/header.component.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header class=\"u-clearfix u-header u-header\" id=\"sec-638c\"><div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n    <a routerLink=\"/\" class=\"u-image u-logo u-image-1\">\n      <img src=\"../../../assets/images/logo.png\" style=\"float: left;\" class=\"u-logo-image u-logo-image-1\"><h1 class=\"title u-text-palette-2-base\">STREETWISE DELIVERY</h1>\n      <!-- <div style=\"font-family: 'brush script mt' !important;\" class=\"sub-title\">Delivery</div> -->\n    </a>\n    <nav class=\"u-menu u-menu-dropdown u-offcanvas u-menu-1\" data-responsive-from=\"XL\">\n\n      <div class=\"for_mobile menu-collapse\" style=\"font-size: 1rem; letter-spacing: 0px; font-weight: 700; text-transform: uppercase;\">\n        <a class=\"u-border-2 u-border-active-palette-1-base u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-nav-link u-text-active-palette-1-base u-text-grey-90 u-text-hover-grey-90\" href=\"#\">\n          <svg><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#menu-hamburger\"></use></svg>\n          <svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"><defs><symbol id=\"menu-hamburger\" viewBox=\"0 0 16 16\" style=\"width: 16px; height: 16px;\"><rect y=\"1\" width=\"16\" height=\"2\"></rect><rect y=\"7\" width=\"16\" height=\"2\"></rect><rect y=\"13\" width=\"16\" height=\"2\"></rect>\n        </symbol>\n        </defs></svg></a>\n      </div>\n\n      <div class=\"for_desktop u-custom-menu u-nav-container\">\n        <ul class=\"u-nav u-unstyled u-nav-1\">\n          <li class=\"u-nav-item\" routerLinkActive=\"active_link\">\n            <a class=\"u-border-2 u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-grey-90 u-text-hover-grey-90\" routerLink=\"/home\" style=\"padding: 10px 0px;\">Home</a>\n          </li>\n          <li class=\"u-nav-item\" routerLinkActive=\"active_link\">\n            <a class=\"u-border-2 u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-grey-90 u-text-hover-grey-90\" routerLink=\"/about\" style=\"padding: 10px 0px;\">About Us</a>\n          </li>\n          <li class=\"u-nav-item\" routerLinkActive=\"active_link\">\n            <a class=\"u-border-2 u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-grey-90 u-text-hover-grey-90\" routerLink=\"/faq\" style=\"padding: 10px 0px;\">F.A.Q</a>\n          </li>\n          <li class=\"u-nav-item\" routerLinkActive=\"active_link\">\n            <a class=\"u-border-2 u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-nav-link u-text-grey-90 u-text-hover-grey-90\" routerLink=\"/contact\" style=\"padding: 10px 0px;\">Contact Us</a>\n          </li>\n          <li class=\"u-nav-item\" style=\"margin-left: 2rem\">\n            <a type=\"button\" (click)=\"basicModal.show()\" class=\"u-btn u-button-style u-palette-3-base u-btn-1 shadow\">Send Parcel</a>\n          </li>\n        </ul>\n      </div>\n\n      <div class=\"for_mobile u-custom-menu u-nav-container-collapse\">\n        <div class=\"u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav\">\n          <div class=\"u-sidenav-overflow\">\n            <div class=\"u-menu-close\" id=\"close_btn\"></div>\n            <ul class=\"u-align-left u-nav u-popupmenu-items u-unstyled u-nav-2\">\n              <li class=\"u-nav-item\" (click)=\"closeBtn()\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\" routerLink=\"/home\" style=\"padding: 10px 20px;\">Home</a></li>\n              <li class=\"u-nav-item\" (click)=\"closeBtn()\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\" routerLink=\"/about\" style=\"padding: 10px 20px;\">About Us</a></li>\n              <!-- <li class=\"u-nav-item\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\" routerLink=\"/quote\" style=\"padding: 10px 20px;\">Get A Quote</a></li> -->\n              <li class=\"u-nav-item\" (click)=\"closeBtn()\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\" routerLink=\"/faq\" style=\"padding: 10px 20px;\">F. A. Qs</a></li>\n              <li class=\"u-nav-item\" (click)=\"closeBtn()\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\" routerLink=\"/contact\" style=\"padding: 10px 20px;\">Contact Us</a></li>\n              <li class=\"u-nav-item\" (click)=\"closeBtn()\" routerLinkActive=\"active_link\"><a class=\"u-button-style u-nav-link\"> &nbsp; </a> </li>\n              <a class=\"u-btn u-button-style u-palette-3-base u-btn-1\" (click)=\"basicModal.show()\">Send Parcel</a>\n            </ul>\n          </div>\n        </div> \n        <div class=\"u-black u-menu-overlay u-opacity u-opacity-70\"></div>\n      </div>\n\n    </nav> \n  </div></header> \n\n\n  <div mdbModal #basicModal=\"mdbModal\" style=\"overflow: auto\" class=\"modal fade\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myBasicModalLabel\" aria-hidden=\"true\">\n    <div class=\"modal-dialog modal-lg\" role=\"document\">\n      <div class=\"modal-content\">\n        <div class=\"modal-header\" style=\"position: relative !important; height: 60px;\">\n          <button type=\"button\" class=\"close pull-right\" aria-label=\"Close\" (click)=\"basicModal.hide()\">\n            <span style=\"font-size: 40px; margin-top: 0px !important;\" aria-hidden=\"true\">×</span>\n          </button>\n          <h4 style=\"margin-top: 0px !important;\" class=\"modal-title\" id=\"myModalLabel\">Send A Parcel</h4>\n        </div>\n        <div class=\"modal-body\">\n          <form class=\"text-center\">\n\n            <div class=\"card shadow\" style=\"margin-bottom: 1.2rem !important;\">\n              <div class=\"u-align-left u-text u-text-2\" style=\"font-size: 14px !important;\"><span style=\"font-weight: 700;\">Hi User,</span>\n                 Kindly note that items heavier than 20kg or items that won't fit in to the courier delivery box won't be dispatched by the rider. Hence, you will need to bring the item to our office and we will get it delivered through other means. \n                 Also, <span style=\"font-weight: 700;\">Ensure all fields are filled correctly and accurately</span>\n              </div>\n            </div>  \n\n            <div #map_canvas id=\"map_canvas\"></div>\n\n            <div class=\"row\">\n              <div class=\"col-lg-6 col-md-6 col-sm-12\">\n                <label>Pickup Location *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"input\" name=\"pickuplocation\" [(ngModel)]=\"pickupcomplete.input\" (ngModelChange)=\"pickupSearchResults(pickupcomplete.input)\"\n                placeholder=\"Enter Pickup location\" style=\"border-bottom: 1px solid #8a8a8a;\">\n                <div class=\"bg-white container\" *ngIf=\"pickupautocompleteItems?.length > 0\">\n                  <div class=\"options text-left shadow_0\" *ngFor=\"let location of pickupautocompleteItems\" (click)=\"selectPickupLocation(location)\">{{location?.description}}</div>\n                </div>\n              </div>\n              <div class=\"col-lg-6 col-md-6 col-sm-12\">\n                <label>Drop Location *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"input\" name=\"droplocation\" [(ngModel)]=\"dropcomplete.input\" (ngModelChange)=\"dropSearchResults(dropcomplete.input)\"\n                  placeholder=\"Enter Drop location\" style=\"border-bottom: 1px solid #8a8a8a;\">\n                <div class=\"bg-white container\" *ngIf=\"dropautocompleteItems?.length > 0\">\n                  <div class=\"options text-left shadow_0\" *ngFor=\"let location of dropautocompleteItems\" (click)=\"selectDropLocation(location)\">{{location?.description}}</div>\n                </div>\n              </div>\n            </div>\n\n\n            <div class=\"row\">\n              <div class=\"col-lg-4 col-md-6 scol-sm-12\">\n                <label style=\"top: -3px !important;\">Email *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"input\" name=\"email \" [(ngModel)]=\"email\"\n                  placeholder=\"Enter Your Email\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n              <div class=\"col-lg-4 col-md-6 col-sm-12\">\n                <label>Phone *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"input\" name=\"phone\" [(ngModel)]=\"phone\"\n                placeholder=\"Enter Phone Number\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n              <div class=\"col-lg-4 col-md-6 col-sm-12\">\n                <label>Delivery date*</label>\n                <input autocomplete=\"false\" type=\"date\" class=\"form-control mb-4 shadow_0\" id=\"date_of_delivery\" name=\"date_of_delivery\" [(ngModel)]=\"date_of_delivery\"\n                placeholder=\"Enter Phone Number\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n            </div>\n\n            <div class=\"row\">\n              <div class=\"col-lg-6 col-md-6 col-sm-12\">\n                <label>First Name *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"firstname\" name=\"firstname\" [(ngModel)]=\"firstname\"\n                placeholder=\"Enter First Name\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n              <div class=\"col-lg-6 col-md-6 col-sm-12\">\n                <label>Last Name *</label>\n                <input autocomplete=\"false\" type=\"text\" class=\"form-control mb-4 shadow_0\" id=\"lastname\" name=\"lastname\" [(ngModel)]=\"lastname\"\n                placeholder=\"Enter Last Name\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n            </div>\n            \n            <div class=\"row\">\n              <div class=\"col-lg-4 col-md-6 col-sm-12\">\n                <label>Height(Inches)</label>\n                <input autocomplete=\"false\" type=\"number\" class=\"form-control mb-4 shadow_0\" id=\"height\" name=\"height\" [(ngModel)]=\"height\"\n                placeholder=\"20\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n              <div class=\"col-lg-4 col-md-6 col-sm-12\">\n                <label>Width</label>\n                <input autocomplete=\"false\" type=\"number\" class=\"form-control mb-4 shadow_0\" id=\"width\" name=\"width\" [(ngModel)]=\"width\"\n                placeholder=\"15\" style=\"border-bottom: 1px solid #8a8a8a;\">\n              </div>\n              <div class=\"col-lg-4 col-md-6 col-sm-12\">\n                <label>Item Type *</label>\n                <select style=\"width: 100%; border: 1px solid #8a8a8a; border-radius: 5px;\" name=\"selected_category\" id=\"selected_category\" [(ngModel)]=\"selected_category\" class=\"browser-default custom-select mb-4\">\n                  <option disabled selected>Select A Category</option>\n                  <option style=\"text-transform: capitalize !important;\" *ngFor=\"let cat of categories\" [value]=\"cat?.name\">{{cat?.name}}</option>\n                </select>\n              </div>\n            </div>\n\n            <div class=\"row\">\n              <div class=\"col-lg-12 col-md-12 col-sm-12\">\n                <label>Description *</label>\n                <textarea maxlength=\"100\" autocomplete=\"false\" type=\"number\" class=\"form-control mb-4 shadow_0\" id=\"desc\" rows=\"2\" name=\"desc\" [(ngModel)]=\"desc\"\n                placeholder=\"Description of the package or additional details\" style=\"border-bottom: 1px solid #8a8a8a;\"></textarea>\n              </div>\n            </div>\n            \n            <button *ngIf=\"!loading\" mdbBtn color=\"primary\" block=\"true\" class=\"my-2 shadow\" type=\"submit\" (click)=\"continue(user?.uid, email, firstname, lastname, height, width, selected_category, pickupcomplete?.input, dropcomplete?.input, phone, date_of_delivery, desc)\">\n                Continue\n            </button>\n\n            <button *ngIf=\"loading\" mdbBtn color=\"primary\" block=\"true\" class=\"my-2 shadow\">\n              <img  src=\"../../../assets/images/loader.gif\" style=\"height: 40px; margin: auto\">\n            </button>\n\n            <div style=\"height: 20px;\">&nbsp;</div>\n            <div>If you have any issues or enquiries, Kindy call <a href=\"tel:+2348066759838\">08066759838</a> or mail <a href=\"mailto:info@streetwisedelivery.com.ng\">info@streetwisedelivery.com.ng</a></div>\n            <div style=\"height: 20px;\">&nbsp;</div>\n\n          </form>\n        </div>\n      </div>\n    </div>\n  </div>\n\n\n<div mdbModal #paymentModal=\"mdbModal\" class=\"modal fade left\" id=\"frameModalTop\" tabindex=\"-1\" role=\"dialog\"\n     aria-labelledby=\"myModalLabel\" aria-hidden=\"true\">\n  <div class=\"modal-dialog\" role=\"document\">\n    <div class=\"modal-content\">\n      <div class=\"modal-header text-center\">\n        <h4 class=\"modal-title w-100 font-weight-bold\">Delivery Details</h4>\n        <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\" (click)=\"frame.hide()\">\n          <span aria-hidden=\"true\">&times;</span>\n        </button>\n      </div>\n      <div class=\"modal-body mx-3\">\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-person-fill\" viewBox=\"0 0 16 16\">\n            <path d=\"M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z\"/>\n          </svg>\n          {{firstname}} &nbsp; {{lastname}} \n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-envelope\" viewBox=\"0 0 16 16\">\n            <path d=\"M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V4zm2-1a1 1 0 0 0-1 1v.217l7 4.2 7-4.2V4a1 1 0 0 0-1-1H2zm13 2.383l-4.758 2.855L15 11.114v-5.73zm-.034 6.878L9.271 8.82 8 9.583 6.728 8.82l-5.694 3.44A1 1 0 0 0 2 13h12a1 1 0 0 0 .966-.739zM1 11.114l4.758-2.876L1 5.383v5.73z\"/>\n          </svg>\n          {{email}}\n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-geo-alt\" viewBox=\"0 0 16 16\">\n            <path d=\"M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z\"/>\n            <path d=\"M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z\"/>\n          </svg>\n          Pick Up Location:  {{pickupcomplete?.input}} \n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-geo-alt-fill\" viewBox=\"0 0 16 16\">\n            <path d=\"M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z\"/>\n          </svg>\n            Drop Location:  {{dropcomplete?.input}}\n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-geo-fill\" viewBox=\"0 0 16 16\">\n            <path fill-rule=\"evenodd\" d=\"M4 4a4 4 0 1 1 4.5 3.969V13.5a.5.5 0 0 1-1 0V7.97A4 4 0 0 1 4 3.999zm2.493 8.574a.5.5 0 0 1-.411.575c-.712.118-1.28.295-1.655.493a1.319 1.319 0 0 0-.37.265.301.301 0 0 0-.057.09V14l.002.008a.147.147 0 0 0 .016.033.617.617 0 0 0 .145.15c.165.13.435.27.813.395.751.25 1.82.414 3.024.414s2.273-.163 3.024-.414c.378-.126.648-.265.813-.395a.619.619 0 0 0 .146-.15.148.148 0 0 0 .015-.033L12 14v-.004a.301.301 0 0 0-.057-.09 1.318 1.318 0 0 0-.37-.264c-.376-.198-.943-.375-1.655-.493a.5.5 0 1 1 .164-.986c.77.127 1.452.328 1.957.594C12.5 13 13 13.4 13 14c0 .426-.26.752-.544.977-.29.228-.68.413-1.116.558-.878.293-2.059.465-3.34.465-1.281 0-2.462-.172-3.34-.465-.436-.145-.826-.33-1.116-.558C3.26 14.752 3 14.426 3 14c0-.599.5-1 .961-1.243.505-.266 1.187-.467 1.957-.594a.5.5 0 0 1 .575.411z\"/>\n          </svg> Distance: \n          {{trip_distance | number}} km\n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-credit-card-fill\" viewBox=\"0 0 16 16\">\n            <path d=\"M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1H0V4zm0 3v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7H0zm3 2h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1z\"/>\n          </svg>\n          Amount to Pay: \n          N{{amount | number}}\n        </div>\n\n        <div class=\"md-form mb-5\">\n          <svg class=\"icon\" xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-card-checklist\" viewBox=\"0 0 16 16\">\n            <path d=\"M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z\"/>\n            <path d=\"M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z\"/>\n          </svg>\n          Description: \n          {{desc}}\n        </div>\n\n      </div>\n      <div class=\"modal-footer d-flex justify-content-center\">\n        <button mdbBtn class=\"pay_btn shadow\" class=\"waves-light\" mdbWavesEffect\n        [disabled]=\"1 > amount || !amount\"\n        angular4-paystack\n        [key]=\"'pk_test_aff83a12bc9631dc681b9ea7f9ce8a9d9ee7969a'\"\n        [email]=\"email\"\n        [amount]=\"amount * 100\"\n        [ref]=\"reference\"\n        (paymentInit)=\"paymentInit()\"\n        (close)=\"paymentCancel()\"\n        (callback)=\"paymentDone($event)\">Make Payment</button>\n      </div> \n    </div>\n  </div>\n</div>"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/about/about.component.html":
/*!****************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/about/about.component.html ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"u-body\">\n    <section class=\"u-clearfix u-section-4\" style=\"margin-top: 3rem;\" id=\"sec-6398\">\n        <div class=\"\">\n          <h1 class=\"u-align-center u-text u-text-palette-5-dark-1 u-text-1\">Who We Are</h1>\n          <p class=\"u-align-center u-text u-text-2\">\n            Streetwise Delivery is an international forwarder specialized in forwarding your shipments from and to any destinations of your choice. We design and implement industry-leading solutions together with our worldwide network of partners. We have over 50 dedicated employees, working around the globe to deliver operational excellence while providing viable answers even to the most challenging supply chain questions.\n    \n            We focus on providing excellence and value to our customer through our team of experts who bring passion to their work at all time. We are totally committed to meeting and exceeding our customers’ expectations. We are your preferred destination for shipping needs.\n        </p>\n          <!-- <a routerLink=\"/contact\" class=\"u-btn u-button-style u-palette-3-base u-btn-1\">Contact Us</a>\n          <a href=\"#\" style=\"padding: 10px 30px !important\" class=\"u-btn u-btn-round u-button-style u-radius-50 u-text-palette-2-base u-white u-btn-2\">Send Package</a> -->\n          <a style=\"padding: 10px 30px !important; font-size: 20px; margin-top: 3rem !important; margin-bottom: 3rem; margin: auto;\" routerLink=\"/contact\" class=\"u-btn u-btn-round u-button-style u-color-scheme-summer-time u-color-style-multicolor-1 u-palette-2-base u-radius-50 u-btn-2 shadow\">Contact Us</a>\n            <div style=\"height: 5rem;\"> &nbsp; </div>\n          <div style=\"position: absolute !important;\" class=\"u-opacity u-opacity-55 u-shape u-shape-svg u-text-palette-5-dark-1 u-shape-1\">\n            <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-1c42\"></use></svg>\n            <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-1c42\"><path d=\"M114.3,152.3l38-38C144.4,130.9,130.9,144.4,114.3,152.3z M117.1,9.1l-108,108c0.8,1.6,1.7,3.2,2.7,4.8l110-110\n                C120.3,10.9,118.7,10,117.1,9.1z M97.5,2L2,97.5c0.4,2,1,4,1.5,5.9l99.9-99.9C101.5,2.9,99.5,2.4,97.5,2z M80,160c2,0,4-0.1,5.9-0.2\n                l73.9-73.9c0.1-2,0.2-3.9,0.2-5.9c0-0.6,0-1.2,0-1.9L78.1,160C78.8,160,79.4,160,80,160z M34.9,146.1c1.5,1,3,2,4.6,2.9L149,39.5\n                c-0.9-1.6-1.9-3.1-2.9-4.6L34.9,146.1z M132.7,19.8L19.8,132.7c1.2,1.3,2.3,2.6,3.6,3.9L136.6,23.4C135.3,22.2,134,21,132.7,19.8z\n                M59.6,157.4l97.8-97.8c-0.5-1.9-1.1-3.8-1.7-5.7L53.9,155.6C55.8,156.3,57.7,156.9,59.6,157.4z M7.6,45.9L45.9,7.6\n                C29.1,15.5,15.5,29.1,7.6,45.9z M80,0c-2.6,0-5.1,0.1-7.6,0.4l-72,72C0.1,74.9,0,77.4,0,80c0,0.1,0,0.2,0,0.2L80.2,0\n                C80.2,0,80.1,0,80,0z\"></path></svg>\n          </div>\n          <!-- <div class=\"u-align-left u-image u-image-circle u-image-1\" data-image-width=\"1470\" data-image-height=\"900\"></div>\n          <div class=\"u-align-left u-image u-image-circle u-image-2\"></div>\n          <div class=\"u-align-left u-image u-image-circle u-image-3\"></div> -->\n          <div style=\"position: absolute !important;\" class=\"u-palette-3-base u-preserve-proportions u-shape u-shape-circle u-shape-2\"></div>\n          <div style=\"position: absolute !important; top: 13rem; z-index: -10;\" class=\"myshape u-shape u-shape-svg u-text-palette-5-light-1 u-shape-3\">\n            <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-3be9\"></use></svg>\n            <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-3be9\" style=\"enable-background:new 0 0 160 160;\"><path d=\"M80,30c27.6,0,50,22.4,50,50s-22.4,50-50,50s-50-22.4-50-50S52.4,30,80,30 M80,0C35.8,0,0,35.8,0,80s35.8,80,80,80s80-35.8,80-80S124.2,0,80,0L80,0z\"></path></svg>\n          </div>\n          <!-- <p class=\"u-align-center u-text u-text-grey-50 u-text-3\">Image from <a href=\"https://www.freepik.com/photos/background\" class=\"u-active-none u-border-1 u-border-grey-75 u-btn u-button-link u-button-style u-hover-none u-none u-text-grey-50 u-btn-2\">Freepik</a>\n          </p> -->\n        </div>\n      </section>\n    <section class=\"u-align-left u-clearfix u-palette-2-base u-section-3\" id=\"carousel_9292\">\n        <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n          <h1 class=\"u-custom-font u-font-montserrat u-text u-text-1\">What We&nbsp;Do</h1>\n          <p style=\"font-size: 18px; font-weight: 300; color: white;\" class=\"u-align-left u-text u-text-2\">\n            Streetwise Delivery is an international forwarder specialized in forwarding your shipments from and to any destinations of your choice. We provide the following specific services:\n          </p>\n          <div class=\"u-expanded-width u-list u-repeater u-list-1\">\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-1\">\n              <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-1\">\n                <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-1\">\n                  <div class=\"u-container-layout u-valign-middle u-container-layout-2\">\n                    <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-3\">01</h1>\n                  </div>\n                </div>\n                <h5 class=\"u-text u-text-4\">Freight Clearing</h5>\n                <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    We guarantee prompt, efficient, and cost-effective clearance of goods of whatever description at overseas Airports and Seaports and can broker freight rates for clients as may be required.\n                </p>\n                <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-2\">Contact Us</a>\n              </div>\n            </div>\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-2\">\n              <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-3\">\n                <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-2\">\n                  <div class=\"u-container-layout u-valign-middle u-container-layout-4\">\n                    <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-5\">02</h1>\n                  </div>\n                </div>\n                <h5 class=\"u-text u-text-6\">Logistics Syndication</h5>\n                <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    We arrange complex local and international logistics for clients to secure the prompt clearing of their goods at airports, seaports, transit routes, company premises, etc.                \n                </p>\n                <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-3\">Contact Us</a>\n              </div>\n            </div>\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n              <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n                <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n                  <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                    <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">03</h1>\n                  </div>\n                </div>\n                <h5 class=\"u-text u-text-8\">Deliveries of Mails, Parcels & Cargoes</h5>\n                <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    We collect and deliver mails, parcels, and cargoes from anywhere in the world even at short notices Door-to-Door.                \n                </p>\n                <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">Contact Us</a>\n              </div>\n            </div>\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n              <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n                <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n                  <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                    <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">04</h1>\n                  </div>\n                </div>\n                <h5 class=\"u-text u-text-8\">Mail Room Management</h5>\n                <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    Our organization manages mailrooms for large and small organizations cheaply and efficiently; using adequately trained personnel.\n                </p>\n                <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">Contact Us</a>\n            </div>\n            </div>\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n                <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n                  <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n                    <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                      <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">03</h1>\n                    </div>\n                  </div>\n                  <h5 class=\"u-text u-text-8\">Warehousing </h5>\n                  <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    We provide warehouses for clients irrespective of location, and guarantee adequate protection of their goods.                \n                  </p>\n                <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">Contact Us</a>\n            </div>\n            </div>\n            <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n                <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n                  <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n                    <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                      <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">04</h1>\n                    </div>\n                  </div>\n                  <h5 class=\"u-text u-text-8\">Haulage</h5>\n                  <p style=\"font-size: 18px; font-weight: 300; color: rgb(88, 87, 87);\">\n                    Our clients are assured of quick deliveries of their heavy cargoes to any location in Turkey and beyond such as the neighbouring countries and entire vworld.\n                    </p>\n                    <a routerLink=\"/contact\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">Contact Us</a>\n                </div>\n            </div>\n          </div>\n        </div>\n      </section>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/contact/contact.component.html":
/*!********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/contact/contact.component.html ***!
  \********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"u-body\">\n    <section class=\"u-clearfix u-section-4\" style=\"margin-top: 1.5rem; margin-bottom: 5rem;\" id=\"sec-6398\">\n      <div class=\"container\"> \n        <h1 class=\"u-align-center u-text u-text-palette-5-dark-1 u-text-1\" style=\"margin-bottom: 1.5rem;\">Contact Us</h1>\n        <p style=\"font-size: 18px; font-weight: 300; color: rgb(86, 84, 84);\" class=\"u-align-left u-text u-text-2\">\n          Please get in touch and our expert support team will answer all your questions\n        </p>\n        <div class=\"map_embed\">\n          <div class=\"mapouter shadow\">\n            <div class=\"gmap_canvas\">\n              <iframe id=\"gmap_canvas\" src=\"https://maps.google.com/maps?q=Iyana%20Ejigbo%20Shopping%20Arcade,%20Ejigbo,%20Lagos&t=&z=13&ie=UTF8&iwloc=&output=embed\" frameborder=\"0\" scrolling=\"no\" marginheight=\"0\" marginwidth=\"0\"></iframe>\n              </div>\n            </div>\n        </div>\n      </div>\n    </section>\n    <app-contact-form></app-contact-form>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/faq/faq.component.html":
/*!************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/faq/faq.component.html ***!
  \************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"u-body\">\n    <section class=\"u-clearfix\" style=\"margin-top: 3rem;\" id=\"sec-6398\">\n        <div class=\"\">\n          <h1 class=\"u-align-center u-text u-text-palette-5-dark-1 u-text-1\">Frequently Asked Questions</h1>\n          <p style=\"font-size: 19px; font-weight: 600;\" class=\"u-align-center u-text u-text-2\">\n                Below are some of the questions frequently asked by our customers    \n            </p>\n\n            <div class=\"container\">\n                <div class=\"card shadow\">\n                    <h6>Do you offer pick-up services?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        Absolute YES! We will assist in picking up the goods in the country you are shipping from. We are in this industry to give stress-free experiences to all our customers.\n                        All we need is the address and pick up contact for authorization and all information sent will be confidential. Pick-up charge will depend on the distance from the warehouse and the bill from the local courier that may be used in case of tight schedule.\n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>Do you repack or cross-check goods sent to your warehouse?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We reserve the rights to check and examine all the goods sent to our offices to avoid carriage of contraband goods, delay and seizure at the ports of loading especially airport.\n                        We repackage to meet up with standards of the both countries’ ports of loading and destination. Most times, repacking may even reduce the weight of the packs.</p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>What type of goods do you ship?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        All goods can be shipped except warship equipment, bomb equipment, ammunition, banned drugs (cocaine, marijuana and others). We can ship dangerous goods, sensitive goods, hazardous goods all with specifications by the countries’ port of loading and destination.\n                        The above goods will not be charged with the same rate as the normal goods charges. The type of goods will determine the mode of shipment either through air or sea freight.\n                    </p>\n                </div>\n                \n                <div class=\"card shadow\">\n                    <h6>How long will my goods be ready for delivery?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        Transit time depends on the mode of shipping, documentation process and booking time.\n                        For air Freight: your goods will be delivered (that mean freighting and clearance) between 3-14 days depending on the country, type of goods, air shipping type (normal or express shipping).\n                        For sea Freight: transit days depend on the type of load method requested for. FCL takes like 35 – 45 days and LCL take like 45-60 days. All the processes will depend on the route of the ship voyage. The above is for transit time between the ports of loading and ports of destination. Clearance may take like 7-14 days.\n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>How do you handle lost or damaged goods?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We take sole responsible of all the damages that occur during packing and shipping. Some damages may be incur by the airliners and shipping lines but we will also communicate with the affected customers to inform on the next steps to take.      \n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>How do you handle lost or damaged goods?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We take sole responsible of all the damages that occur during packing and shipping. Some damages may be incur by the airliners and shipping lines but we will also communicate with the affected customers to inform on the next steps to take.      \n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>What is Streetwise Delivery Freight Internaional coverage?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        Our company has  international coverage network. We have partners in almost all the countries in the world. You can rely on our services ranging from pick-up services via shipping to delivery aspect.\n                        We covered Asia, Europe, Australia, North and South America, Africa. Did you have shipment in Poland, Dubai, China, India, United Kingdom, Germany, USA, Brazil, Canada, Indonesia and others. Just send mail through our contact or request quote page, we will assist you. Our agents will be glad to assist you in any service you may request for.\n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>How long can my goods stay in your warehouse before shipment?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        For Air Freight: The goods can stay as long as you still need to buy more goods for shipment. We will need to determine the durability of the goods sent to our warehouse. Any perishable goods is advised to be shipped immediately with express shipping.\n                        For Sea Freight: depending on the sea freight type. If you are using LCL (Less Container Load) it will stay with us, in order to get other consolidated goods ready for shipping process. For FCL (Full Container Load), it may not stay long because of the time schedule from the shipping lines. We have to meet up after booking.\n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>Can I pay for goods before it arrive?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        Payment is subject to mode of shipping. For sea freight, customers will need pay for freight and documentation at the beginning of the transactions. Payment for clearance will be determined by the custom duty charges and handling charges.\n                        For air freight services, payment may be made immediately. However, air freight services from some countries may require instant payment. All transactions will be made through company bank account(s) for legal references and proceedings. We will never accept payment if we are sure rendering services to you.    \n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>How do I know the status of my goods?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We always inform our customers on the update of the progress on their shipment. We use technologies like call, SMS, Email, tracking route for some. Update on Every stage from pick-up, freight and shipping, custom clearance to delivery will be sent to the customer, even when not requested for.\n                        You can rely on our customer services to relate with you as friends. We treat all customers equally and with due respect.       \n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>How do I know the status of my goods?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We always inform our customers on the update of the progress on their shipment. We use technologies like call, SMS, Email, tracking route for some. Update on Every stage from pick-up, freight and shipping, custom clearance to delivery will be sent to the customer, even when not requested for.\n                        You can rely on our customer services to relate with you as friends. We treat all customers equally and with due respect.       \n                    </p>\n                </div>\n\n                <div class=\"card shadow\">\n                    <h6>Which shipping method do you specialize in?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        With our vast knowledge and understanding of shipping, we are specialists in handle cargo on different routes. When it comes to air freight services, we can coordinate your shipping plans with our teams that take pleasure in delivery excellence.\n                        All documentations needed for particular consignment will handled over through airline operation to the clearing of the goods at the ports of destination.    \n                    </p>\n                </div>  \n                \n                <div class=\"card shadow\">\n                    <h6>How do you charge for freight services?</h6>\n                    <p class=\"u-align-left u-text u-text-2\" style=\"font-size: 16px !important;\">\n                        We charge based on the route of the freight. Air freight forwarding can be charge either by weight or volume depends on the state of the commodities (solid, liquid or gases). By weight, kilogram can used from countries like China, India, Germany, Poland, Indonesia, UAE, South Africa and other countries. Canada and USA use pounds (lbs) in weight measure.\n                        Sea freight are charges based on containers if the shipment is FCL (Full Cargo Load). We charge based on CBM (Cubic Meter) for Less Cargo Load. All freight forwarding services from attract handling charges whether inbound or outbound all the goods via United Best Express Freight Company.    \n                    </p>\n                </div> \n\n            </div>\n            \n          \n        <div style=\"height: 5rem;\"> &nbsp; </div>\n          <div style=\"position: absolute !important; top: 12rem;\" class=\"u-opacity u-opacity-55 u-shape u-shape-svg u-text-palette-5-dark-1 u-shape-1\">\n            <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-1c42\"></use></svg>\n            <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-1c42\"><path d=\"M114.3,152.3l38-38C144.4,130.9,130.9,144.4,114.3,152.3z M117.1,9.1l-108,108c0.8,1.6,1.7,3.2,2.7,4.8l110-110\n                C120.3,10.9,118.7,10,117.1,9.1z M97.5,2L2,97.5c0.4,2,1,4,1.5,5.9l99.9-99.9C101.5,2.9,99.5,2.4,97.5,2z M80,160c2,0,4-0.1,5.9-0.2\n                l73.9-73.9c0.1-2,0.2-3.9,0.2-5.9c0-0.6,0-1.2,0-1.9L78.1,160C78.8,160,79.4,160,80,160z M34.9,146.1c1.5,1,3,2,4.6,2.9L149,39.5\n                c-0.9-1.6-1.9-3.1-2.9-4.6L34.9,146.1z M132.7,19.8L19.8,132.7c1.2,1.3,2.3,2.6,3.6,3.9L136.6,23.4C135.3,22.2,134,21,132.7,19.8z\n                M59.6,157.4l97.8-97.8c-0.5-1.9-1.1-3.8-1.7-5.7L53.9,155.6C55.8,156.3,57.7,156.9,59.6,157.4z M7.6,45.9L45.9,7.6\n                C29.1,15.5,15.5,29.1,7.6,45.9z M80,0c-2.6,0-5.1,0.1-7.6,0.4l-72,72C0.1,74.9,0,77.4,0,80c0,0.1,0,0.2,0,0.2L80.2,0\n                C80.2,0,80.1,0,80,0z\"></path></svg>\n          </div>\n          \n          <div style=\"position: absolute !important;\" class=\"u-palette-3-base u-preserve-proportions u-shape u-shape-circle u-shape-2\"></div>\n          <div style=\"position: absolute !important; top: 13rem; z-index: -10;\" class=\"myshape u-shape u-shape-svg u-text-palette-5-light-1 u-shape-3\">\n            <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-3be9\"></use></svg>\n            <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-3be9\" style=\"enable-background:new 0 0 160 160;\"><path d=\"M80,30c27.6,0,50,22.4,50,50s-22.4,50-50,50s-50-22.4-50-50S52.4,30,80,30 M80,0C35.8,0,0,35.8,0,80s35.8,80,80,80s80-35.8,80-80S124.2,0,80,0L80,0z\"></path></svg>\n          </div>\n          \n        </div>\n      </section>\n</div>\n"

/***/ }),

/***/ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/pages/home/home.component.html ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<div class=\"u-body\">\n  <section class=\"u-clearfix u-image u-section-1\" id=\"carousel_91d0\" data-image-width=\"1980\" data-image-height=\"1114\">\n    <div class=\"u-clearfix u-sheet u-sheet-1\">\n      <div class=\"u-align-left u-container-style u-group u-palette-2-base u-group-1\">\n        <div class=\"u-container-layout u-valign-middle u-container-layout-1 shadow\">\n          <h1 class=\"u-text u-text-1\">Streetwise Delivery Shipping Company</h1>\n          <p class=\"u-large-text u-text u-text-variant u-text-2\">We are your preferred destination for any shipping needs and your no one international forwarder specialist.</p>\n          \n          <!-- <a href=\"#\" class=\"u-btn u-btn-round u-button-style u-radius-50 u-text-palette-2-base u-white u-btn-2\">Read More</a> -->\n          <a (click)=\"showModal()\" style=\"padding: 10px 30px !important\" class=\"u-btn u-btn-round u-button-style u-radius-50 u-text-palette-2-base u-white u-btn-2 shadow\">Send Package</a>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"u-align-center-lg u-align-center-md u-align-center-sm u-align-center-xs u-clearfix u-section-2\" id=\"carousel_a924\">\n    <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n      <div class=\"u-shape u-shape-svg u-text-palette-5-dark-1 u-shape-1\">\n        <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-db78\"></use></svg>\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-db78\"><path d=\"M114.3,152.3l38-38C144.4,130.9,130.9,144.4,114.3,152.3z M117.1,9.1l-108,108c0.8,1.6,1.7,3.2,2.7,4.8l110-110\n  C120.3,10.9,118.7,10,117.1,9.1z M97.5,2L2,97.5c0.4,2,1,4,1.5,5.9l99.9-99.9C101.5,2.9,99.5,2.4,97.5,2z M80,160c2,0,4-0.1,5.9-0.2\n  l73.9-73.9c0.1-2,0.2-3.9,0.2-5.9c0-0.6,0-1.2,0-1.9L78.1,160C78.8,160,79.4,160,80,160z M34.9,146.1c1.5,1,3,2,4.6,2.9L149,39.5\n  c-0.9-1.6-1.9-3.1-2.9-4.6L34.9,146.1z M132.7,19.8L19.8,132.7c1.2,1.3,2.3,2.6,3.6,3.9L136.6,23.4C135.3,22.2,134,21,132.7,19.8z\n  M59.6,157.4l97.8-97.8c-0.5-1.9-1.1-3.8-1.7-5.7L53.9,155.6C55.8,156.3,57.7,156.9,59.6,157.4z M7.6,45.9L45.9,7.6\n  C29.1,15.5,15.5,29.1,7.6,45.9z M80,0c-2.6,0-5.1,0.1-7.6,0.4l-72,72C0.1,74.9,0,77.4,0,80c0,0.1,0,0.2,0,0.2L80.2,0\n  C80.2,0,80.1,0,80,0z\"></path></svg>\n      </div>\n      <div class=\"u-palette-3-base u-shape u-shape-circle u-shape-2\"></div>\n      <div class=\"u-align-left u-container-style u-grey-5 u-group u-group-1\">\n        <div class=\"u-container-layout u-valign-middle u-container-layout-1\">\n          <h1 class=\"u-text u-text-palette-2-base u-text-1\">About Us</h1>\n          <p class=\"u-text u-text-2\">\n            Streetwise Delivery is an international forwarder specialized in forwarding your shipments from and to any destinations of your choice. \n            We design and implement industry-leading solutions together with our worldwide network of partners. We are committed to rendering top-rated services at all times. \n          </p>\n          <a routerLink=\"/about\" class=\"u-btn u-btn-round u-button-style u-color-scheme-summer-time u-color-style-multicolor-1 u-palette-2-base u-radius-50 u-btn-2 shadow\">Learn more</a>\n        </div>\n      </div>\n      <img class=\"u-expanded-width-xs u-image u-image-1\" src=\"../../../assets/images/depositphotos_57420787-stock-photo-customer-signing-for-delivery.jpg\">\n      <img class=\"u-border-11 u-border-white u-image u-image-2\" src=\"../../../assets/images/162881019-delivery-service-during-lockdown-close-up-cropped-view-of-unrecognizable-african-american-male-couri.jpg\">\n    </div>\n  </section>\n  <section class=\"u-align-left u-clearfix u-palette-2-base u-section-3\" id=\"carousel_9292\">\n    <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n      <h1 class=\"u-custom-font u-font-montserrat u-text u-text-1\">What We&nbsp;Do?</h1>\n      <p class=\"u-text u-text-2\">\n        We are your preferred destination for any shipping needs and your no one international forwarder specialist. We strive every time to make our services a reference point in the courier and logistic management services in Nigeria and where requested outside Nigeria.     \n      </p>\n      <div class=\"u-expanded-width u-list u-repeater u-list-1\">\n        <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-1\">\n          <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-1\">\n            <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-1\">\n              <div class=\"u-container-layout u-valign-middle u-container-layout-2\">\n                <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-3\">01</h1>\n              </div>\n            </div>\n            <h5 class=\"u-text u-text-4\">Letters and Parcels Delivery</h5>\n            <a routerLink=\"/about\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-2\">learn more</a>\n          </div>\n        </div>\n        <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-2\">\n          <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-3\">\n            <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-2\">\n              <div class=\"u-container-layout u-valign-middle u-container-layout-4\">\n                <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-5\">02</h1>\n              </div>\n            </div>\n            <h5 class=\"u-text u-text-6\">Freight Forwarding</h5>\n            <a routerLink=\"/about\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-3\">learn more</a>\n          </div>\n        </div>\n        <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n          <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n            <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n              <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">03</h1>\n              </div>\n            </div>\n            <h5 class=\"u-text u-text-8\">Warehosuing & Haulage</h5>\n            <a routerLink=\"/about\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">learn more</a>\n          </div>\n        </div>\n        <div class=\"u-align-left u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-3\">\n          <div class=\"u-container-layout u-similar-container u-valign-top u-container-layout-5\">\n            <div class=\"u-align-center u-border-4 u-border-palette-2-base u-container-style u-group u-radius-50 u-shape-round u-group-3\">\n              <div class=\"u-container-layout u-valign-middle u-container-layout-6\">\n                <h1 class=\"u-align-center u-custom-font u-font-ubuntu u-text u-text-palette-5-dark-3 u-text-7\">04</h1>\n              </div>\n            </div>\n            <h5 class=\"u-text u-text-8\">Mail Room Management</h5>\n            <a routerLink=\"/about\" class=\"u-active-none u-border-2 u-border-palette-2-base u-btn u-btn-rectangle u-button-style u-hover-none u-none u-text-body-color u-btn-4\">learn more</a>\n          </div>\n        </div>\n      </div>\n    </div>\n  </section>\n  <section class=\"u-clearfix u-section-4\" id=\"sec-6398\">\n    <div class=\"u-clearfix u-sheet u-sheet-1\">\n      <h1 class=\"u-align-center u-text u-text-palette-5-dark-1 u-text-1\">Smart Delivery</h1>\n      <p class=\"u-align-center u-text u-text-2\">\n        Send your letters and parcels with ease. In just three steps, you are good to go. Click on the button below to fill the delivery form which includes the pick up location and drop location, Make payment and get the parcel delivered in no time\n      </p>\n      <a (click)=\"showModal()\" class=\"u-btn u-button-style u-palette-3-base u-btn-1 shadow\">Send Parcel</a>\n      <div class=\"u-opacity u-opacity-55 u-shape u-shape-svg u-text-palette-5-dark-1 u-shape-1\">\n        <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-1c42\"></use></svg>\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-1c42\"><path d=\"M114.3,152.3l38-38C144.4,130.9,130.9,144.4,114.3,152.3z M117.1,9.1l-108,108c0.8,1.6,1.7,3.2,2.7,4.8l110-110\n            C120.3,10.9,118.7,10,117.1,9.1z M97.5,2L2,97.5c0.4,2,1,4,1.5,5.9l99.9-99.9C101.5,2.9,99.5,2.4,97.5,2z M80,160c2,0,4-0.1,5.9-0.2\n            l73.9-73.9c0.1-2,0.2-3.9,0.2-5.9c0-0.6,0-1.2,0-1.9L78.1,160C78.8,160,79.4,160,80,160z M34.9,146.1c1.5,1,3,2,4.6,2.9L149,39.5\n            c-0.9-1.6-1.9-3.1-2.9-4.6L34.9,146.1z M132.7,19.8L19.8,132.7c1.2,1.3,2.3,2.6,3.6,3.9L136.6,23.4C135.3,22.2,134,21,132.7,19.8z\n            M59.6,157.4l97.8-97.8c-0.5-1.9-1.1-3.8-1.7-5.7L53.9,155.6C55.8,156.3,57.7,156.9,59.6,157.4z M7.6,45.9L45.9,7.6\n            C29.1,15.5,15.5,29.1,7.6,45.9z M80,0c-2.6,0-5.1,0.1-7.6,0.4l-72,72C0.1,74.9,0,77.4,0,80c0,0.1,0,0.2,0,0.2L80.2,0\n            C80.2,0,80.1,0,80,0z\"></path></svg>\n      </div>\n      <div class=\"u-align-left u-image u-image-circle u-image-1\" data-image-width=\"1470\" data-image-height=\"900\"></div>\n      <div class=\"u-align-left u-image u-image-circle u-image-2\"></div>\n      <div class=\"u-align-left u-image u-image-circle u-image-3\"></div>\n      <div class=\"u-palette-3-base u-preserve-proportions u-shape u-shape-circle u-shape-2\"></div>\n      <div class=\"u-shape u-shape-svg u-text-palette-5-light-1 u-shape-3\">\n        <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-3be9\"></use></svg>\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-3be9\" style=\"enable-background:new 0 0 160 160;\"><path d=\"M80,30c27.6,0,50,22.4,50,50s-22.4,50-50,50s-50-22.4-50-50S52.4,30,80,30 M80,0C35.8,0,0,35.8,0,80s35.8,80,80,80s80-35.8,80-80S124.2,0,80,0L80,0z\"></path></svg>\n      </div>\n      <!-- <p class=\"u-align-center u-text u-text-grey-50 u-text-3\">Image from <a href=\"https://www.freepik.com/photos/background\" class=\"u-active-none u-border-1 u-border-grey-75 u-btn u-button-link u-button-style u-hover-none u-none u-text-grey-50 u-btn-2\">Freepik</a>\n      </p> -->\n    </div>\n  </section>\n  <section class=\"u-align-left u-clearfix u-palette-2-base u-section-5\" id=\"carousel_6915\">\n    <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n      <div class=\"my_bg u-palette-3-base u-shape u-shape-rectangle u-shape-1\">\n        <!-- <img src=\"https://www.coscourier.com/ressources/images/1cfc9ac52211.jpg\"> -->\n      </div>\n      \n      <h2 class=\"u-text u-text-1\">Smart Tracking, track the movement of your shipment </h2>\n      <div style=\"max-width: 400px; text-align: left; margin-top: 2rem;\">\n        We ensure effective tracking which results to timely completion of your cargo movement to destination. We ensure our smart tracking system is efficient and refreshing so as to keep you abreast the location of your shipment per time.\n        To track your shipment, just input the tracking ID of your shipment in the box below.\n      </div>\n      <div style=\"height: unset !important;\" class=\"u-gallery u-layout-grid u-lightbox u-show-text-on-hover u-gallery-1\">\n        <div class=\"u-gallery-inner u-gallery-inner-1\">\n          <!-- <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"800\" data-image-height=\"800\">\n              <img class=\"u-back-image u-expanded u-back-image-1\" src=\"../../../assets/images/\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-1\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div>\n          <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"700\" data-image-height=\"716\">\n              <img class=\"u-back-image u-expanded u-back-image-2\" src=\"../../../assets/images/okay_package.jpg\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-2\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div>\n          <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"1200\" data-image-height=\"675\">\n              <img class=\"u-back-image u-expanded u-back-image-3\" src=\"images/-min.jpg\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-3\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div>\n          <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"626\" data-image-height=\"417\">\n              <img class=\"u-back-image u-expanded u-back-image-4\" src=\"images/ve-people-japanese-female-boss-supervisor-teaching-intern-new-employee-hispanic-girl-helping-with-difficult-assignment-mode.jpg?version=\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-4\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div>\n          <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"800\" data-image-height=\"800\">\n              <img class=\"u-back-image u-expanded u-back-image-5\" src=\"images/rg-min.jpg\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-5\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div>\n          <div class=\"u-effect-fade u-gallery-item\">\n            <div class=\"u-back-slide\" data-image-width=\"626\" data-image-height=\"417\">\n              <img class=\"u-back-image u-expanded u-back-image-6\" src=\"images/flat-lay-office-desk-assortment-with-empty-screen-tablet_23-2148707960.jpg\">\n            </div>\n            <div class=\"u-over-slide u-shading u-over-slide-6\">\n              <h3 class=\"u-gallery-heading\"></h3>\n              <p class=\"u-gallery-text\"></p>\n            </div>\n          </div> -->\n\n          <form source=\"custom\" name=\"form\">\n            <div class=\"u-form-email u-form-group\">\n              <label for=\"email-0bab\" class=\"u-form-control-hidden u-label\">Email</label>\n              <input type=\"email\" placeholder=\"Enter a valid tracking ID\" id=\"email-0bab\" name=\"email\" class=\"u-border-1 u-border-grey-30 u-input u-input-rectangle u-white\" required=\"\">\n            </div>\n            <a href=\"#\" class=\"u-btn u-btn-round u-button-style u-radius-50 u-text-palette-2-base u-white u-btn-2 shadow\">Track your goods</a>\n          </form>\n        </div>\n      </div>\n    \n    </div>\n  </section>\n  <section class=\"u-clearfix u-section-6\" id=\"carousel_c15d\">\n    <div class=\"u-clearfix u-sheet u-valign-middle u-sheet-1\">\n      <div class=\"u-shape u-shape-svg u-text-palette-5-dark-1 u-shape-1\">\n        <svg class=\"u-svg-link\" preserveAspectRatio=\"none\" viewBox=\"0 0 160 160\"><use xmlns:xlink=\"http://www.w3.org/1999/xlink\" xlink:href=\"#svg-db78\"></use></svg>\n        <svg xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" version=\"1.1\" xml:space=\"preserve\" class=\"u-svg-content\" viewBox=\"0 0 160 160\" x=\"0px\" y=\"0px\" id=\"svg-db78\"><path d=\"M114.3,152.3l38-38C144.4,130.9,130.9,144.4,114.3,152.3z M117.1,9.1l-108,108c0.8,1.6,1.7,3.2,2.7,4.8l110-110\n          C120.3,10.9,118.7,10,117.1,9.1z M97.5,2L2,97.5c0.4,2,1,4,1.5,5.9l99.9-99.9C101.5,2.9,99.5,2.4,97.5,2z M80,160c2,0,4-0.1,5.9-0.2\n          l73.9-73.9c0.1-2,0.2-3.9,0.2-5.9c0-0.6,0-1.2,0-1.9L78.1,160C78.8,160,79.4,160,80,160z M34.9,146.1c1.5,1,3,2,4.6,2.9L149,39.5\n          c-0.9-1.6-1.9-3.1-2.9-4.6L34.9,146.1z M132.7,19.8L19.8,132.7c1.2,1.3,2.3,2.6,3.6,3.9L136.6,23.4C135.3,22.2,134,21,132.7,19.8z\n          M59.6,157.4l97.8-97.8c-0.5-1.9-1.1-3.8-1.7-5.7L53.9,155.6C55.8,156.3,57.7,156.9,59.6,157.4z M7.6,45.9L45.9,7.6\n          C29.1,15.5,15.5,29.1,7.6,45.9z M80,0c-2.6,0-5.1,0.1-7.6,0.4l-72,72C0.1,74.9,0,77.4,0,80c0,0.1,0,0.2,0,0.2L80.2,0\n          C80.2,0,80.1,0,80,0z\"></path></svg>\n      </div>\n      <div class=\"u-palette-3-base u-shape u-shape-circle u-shape-2\"></div>\n        <div class=\"u-expanded-width-sm u-image u-image-circle u-image-1\"></div>\n        <div class=\"u-align-left u-container-style u-group u-palette-2-base u-group-1\">\n          <div class=\"u-container-layout u-valign-middle u-container-layout-1 shadow\">\n            <h2 class=\"u-text u-text-1\">1. Quick Response Time</h2>\n            <div class=\"u-text u-text-2\">We always respond quickly to requests.</div>\n            \n            <h2 class=\"u-text u-text-1\">2. Timely Help</h2>\n            <div class=\"u-text u-text-2\">Our staff always find a way to be of help on every request. </div>\n            \n            <h2 class=\"u-text u-text-1\">3. Track and Monitor</h2>\n            <div class=\"u-text u-text-2\">You can track your shipment with ease.</div>\n            \n            <h2 class=\"u-text u-text-1\">4. Personalised Services</h2>\n            <div class=\"u-text u-text-2\">Assured discount on your shipment.</div>\n                \n            <!-- <a href=\"#\" class=\"u-btn u-btn-round u-button-style u-color-scheme-summer-time u-color-style-multicolor-1 u-radius-50 u-white u-btn-2\">Learn more</a> -->\n          </div>\n        </div>\n        <div class=\"u-image u-image-circle u-image-2\"></div>\n        <h1 class=\"u-text u-text-palette-2-base u-text-4\">Why Us?</h1>\n    </div>\n  </section>\n  <app-contact-form></app-contact-form>\n</div>"

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/home/home.component */ "./src/app/pages/home/home.component.ts");
/* harmony import */ var _pages_about_about_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/about/about.component */ "./src/app/pages/about/about.component.ts");
/* harmony import */ var _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/contact/contact.component */ "./src/app/pages/contact/contact.component.ts");
/* harmony import */ var _pages_faq_faq_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/faq/faq.component */ "./src/app/pages/faq/faq.component.ts");







const routes = [
    // { path: "**", component: LoginComponent},
    { path: "", component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"] },
    { path: "home", component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"] },
    { path: "about", component: _pages_about_about_component__WEBPACK_IMPORTED_MODULE_4__["AboutComponent"] },
    { path: "contact", component: _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_5__["ContactComponent"] },
    { path: "faq", component: _pages_faq_faq_component__WEBPACK_IMPORTED_MODULE_6__["FaqComponent"] }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { scrollPositionRestoration: 'enabled', onSameUrlNavigation: 'reload' })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! aos */ "./node_modules/aos/dist/aos.js");
/* harmony import */ var aos__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(aos__WEBPACK_IMPORTED_MODULE_2__);



let AppComponent = class AppComponent {
    constructor() {
    }
    ngOnInit() {
        aos__WEBPACK_IMPORTED_MODULE_2__["init"]();
    }
};
AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: __webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/index.js!./src/app/app.component.html"),
        styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm2015/animations.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng-uikit-pro-standard */ "./node_modules/ng-uikit-pro-standard/fesm2015/ng-uikit-pro-standard.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _app_app_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../app/app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _components_header_header_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./components/header/header.component */ "./src/app/components/header/header.component.ts");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./pages/home/home.component */ "./src/app/pages/home/home.component.ts");
/* harmony import */ var _pages_about_about_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./pages/about/about.component */ "./src/app/pages/about/about.component.ts");
/* harmony import */ var _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./pages/contact/contact.component */ "./src/app/pages/contact/contact.component.ts");
/* harmony import */ var _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./components/footer/footer.component */ "./src/app/components/footer/footer.component.ts");
/* harmony import */ var _pages_faq_faq_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./pages/faq/faq.component */ "./src/app/pages/faq/faq.component.ts");
/* harmony import */ var _services_maps_service__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./services/maps.service */ "./src/app/services/maps.service.ts");
/* harmony import */ var _angular_fire__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @angular/fire */ "./node_modules/@angular/fire/fesm2015/angular-fire.js");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/fesm2015/angular-fire-auth.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js");
/* harmony import */ var angular4_paystack__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! angular4-paystack */ "./node_modules/angular4-paystack/fesm2015/angular4-paystack.js");
/* harmony import */ var _components_contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./components/contact-form/contact-form.component */ "./src/app/components/contact-form/contact-form.component.ts");






















let AppModule = class AppModule {
};
AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
        declarations: [
            _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
            _components_header_header_component__WEBPACK_IMPORTED_MODULE_10__["HeaderComponent"],
            _pages_home_home_component__WEBPACK_IMPORTED_MODULE_11__["HomeComponent"],
            _pages_about_about_component__WEBPACK_IMPORTED_MODULE_12__["AboutComponent"],
            _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_13__["ContactComponent"],
            _components_footer_footer_component__WEBPACK_IMPORTED_MODULE_14__["FooterComponent"],
            _pages_faq_faq_component__WEBPACK_IMPORTED_MODULE_15__["FaqComponent"],
            _components_contact_form_contact_form_component__WEBPACK_IMPORTED_MODULE_21__["ContactFormComponent"]
        ],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
            _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"],
            _app_app_routing_module__WEBPACK_IMPORTED_MODULE_9__["AppRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"],
            _angular_fire__WEBPACK_IMPORTED_MODULE_17__["AngularFireModule"].initializeApp(src_environments_environment__WEBPACK_IMPORTED_MODULE_8__["environment"].config),
            _angular_fire_auth__WEBPACK_IMPORTED_MODULE_18__["AngularFireAuthModule"],
            _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_19__["AngularFirestoreModule"],
            ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_6__["MDBBootstrapModulesPro"].forRoot(),
            ng_uikit_pro_standard__WEBPACK_IMPORTED_MODULE_6__["ToastModule"].forRoot(),
            angular4_paystack__WEBPACK_IMPORTED_MODULE_20__["Angular4PaystackModule"].forRoot('pk_test_aff83a12bc9631dc681b9ea7f9ce8a9d9ee7969a'),
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"],
        ],
        providers: [_services_maps_service__WEBPACK_IMPORTED_MODULE_16__["MapsService"]],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]],
        schemas: [_angular_core__WEBPACK_IMPORTED_MODULE_3__["NO_ERRORS_SCHEMA"], _angular_core__WEBPACK_IMPORTED_MODULE_3__["CUSTOM_ELEMENTS_SCHEMA"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/components/contact-form/contact-form.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/components/contact-form/contact-form.component.scss ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvY29udGFjdC1mb3JtL2NvbnRhY3QtZm9ybS5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/contact-form/contact-form.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/components/contact-form/contact-form.component.ts ***!
  \*******************************************************************/
/*! exports provided: ContactFormComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactFormComponent", function() { return ContactFormComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js");
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/services/api.service */ "./src/app/services/api.service.ts");




let ContactFormComponent = class ContactFormComponent {
    constructor(api, afs) {
        this.api = api;
        this.afs = afs;
        this.success = false;
        this.loading = false;
    }
    ngOnInit() {
    }
    submit(name, email, message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading = true;
            console.log(name, email, message);
            try {
                let id = yield this.afs.createId();
                this.api.getContact(id).set({
                    name: name, email: email, message: message, id: id, date: new Date().getTime()
                }).then(() => {
                    setTimeout(() => {
                        alert('Thank you! Your message has been sent. We will get back to you shortly');
                        this.loading = false;
                        this.name = '';
                        this.email = '';
                        this.message = '';
                    }, 2000);
                });
            }
            catch (error) {
                console.log(error);
            }
        });
    }
};
ContactFormComponent.ctorParameters = () => [
    { type: src_app_services_api_service__WEBPACK_IMPORTED_MODULE_3__["ApiService"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] }
];
ContactFormComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-contact-form',
        template: __webpack_require__(/*! raw-loader!./contact-form.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/contact-form/contact-form.component.html"),
        styles: [__webpack_require__(/*! ./contact-form.component.scss */ "./src/app/components/contact-form/contact-form.component.scss")]
    })
], ContactFormComponent);



/***/ }),

/***/ "./src/app/components/footer/footer.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/footer/footer.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvZm9vdGVyL2Zvb3Rlci5jb21wb25lbnQuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/components/footer/footer.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/footer/footer.component.ts ***!
  \*******************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FooterComponent = class FooterComponent {
    constructor() { }
    ngOnInit() {
    }
};
FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-footer',
        template: __webpack_require__(/*! raw-loader!./footer.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/footer/footer.component.html"),
        styles: [__webpack_require__(/*! ./footer.component.scss */ "./src/app/components/footer/footer.component.scss")]
    })
], FooterComponent);



/***/ }),

/***/ "./src/app/components/header/header.component.scss":
/*!*********************************************************!*\
  !*** ./src/app/components/header/header.component.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".title {\n  font-size: 20px;\n  font-weight: 700;\n  font-family: Arial !important;\n}\n\n.sub-title {\n  font-family: \"Brush Script MT\" !important;\n  color: #505151;\n  font-size: 17px;\n}\n\nnav {\n  margin-top: -70px !important;\n}\n\n.u-nav-item {\n  margin-left: 0.8rem;\n  margin-right: 0.8rem;\n  border-bottom: solid 3px transparent;\n  border-top: none;\n  border-left: none;\n  border-right: none;\n  border-bottom-left-radius: 3px;\n  border-bottom-right-radius: 3px;\n}\n\n@media (min-width: 990px) {\n  .for_mobile {\n    display: none !important;\n  }\n\n  .for_desktop {\n    display: unset !important;\n  }\n}\n\n@media (max-width: 990px) {\n  .for_desktop {\n    display: none !important;\n  }\n\n  .u-header .u-image-1 {\n    width: 64px;\n    height: unset !important;\n    margin: unset !important;\n    /* height: 32px; */\n  }\n\n  .col-sm-12 {\n    margin-top: 10px !important;\n    margin-bottom: 10px !important;\n  }\n}\n\n.active_link {\n  border-bottom: solid 3px #193eb8;\n  border-top: none;\n  border-left: none;\n  border-right: none;\n  border-bottom-left-radius: 3px;\n  border-bottom-right-radius: 3px;\n}\n\n.card {\n  border-radius: 5px;\n  padding: 8px;\n  height: auto;\n  margin: 15px 0px;\n}\n\ninput, select, mdb-select-2 {\n  padding: 8px 16px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  font-size: 16px;\n  font-weight: 500;\n  height: 45px;\n  color: #141414 !important;\n}\n\ntextarea {\n  padding: 8px 16px;\n  margin-top: 10px;\n  margin-bottom: 10px;\n  font-size: 16px;\n  font-weight: 500;\n  color: #141414 !important;\n}\n\n.row {\n  margin-top: 10px;\n  margin-bottom: 10px;\n}\n\n.options {\n  height: 40px;\n  width: 100%;\n  font-size: 16px;\n  margin-left: 0px;\n  padding: 8px 16px;\n  display: inline-block !important;\n  overflow-x: hidden !important;\n  cursor: pointer;\n}\n\n.options:hover {\n  background-color: #193eb8;\n  color: white;\n  height: 40px;\n  width: 100%;\n  font-size: 16px;\n  margin-left: 0px;\n  padding: 8px 16px;\n  display: inline-block !important;\n  overflow: hidden !important;\n  cursor: pointer;\n}\n\n.bg-white {\n  background-color: white;\n  position: absolute;\n  top: 50px;\n  z-index: 99999;\n}\n\n.shadow_0 {\n  box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075) !important;\n}\n\nlabel {\n  position: absolute;\n  left: 30px;\n  font-size: 12px;\n  color: #193eb8;\n  padding: 0px 8px;\n  background-color: whitesmoke;\n}\n\n.mb-5 svg {\n  margin-right: 30px !important;\n  color: #a7a7a7;\n}\n\n.pay_btn {\n  background-color: #193eb8 !important;\n}\n\nform {\n  border: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29tcG9uZW50cy9oZWFkZXIvQzpcXFVzZXJzXFxIUFxcRGVza3RvcFxcTVkgUFJPSkVDVFNcXFN0cmVldHdpc2Uvc3JjXFxhcHBcXGNvbXBvbmVudHNcXGhlYWRlclxcaGVhZGVyLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9jb21wb25lbnRzL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtBQ0NKOztBREVBO0VBQ0kseUNBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0NKOztBREVDO0VBQ0ksNEJBQUE7QUNDTDs7QURFQTtFQUdJLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSxvQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLDhCQUFBO0VBQ0EsK0JBQUE7QUNESjs7QURJQTtFQUNJO0lBQ0ksd0JBQUE7RUNETjs7RURHRTtJQUNJLHlCQUFBO0VDQU47QUFDRjs7QURHQTtFQUNJO0lBQ0ksd0JBQUE7RUNETjs7RURHRTtJQUNJLFdBQUE7SUFDQSx3QkFBQTtJQUNBLHdCQUFBO0lBQ0Esa0JBQUE7RUNBTjs7RURLRTtJQUNJLDJCQUFBO0lBQ0EsOEJBQUE7RUNGTjtBQUNGOztBREtBO0VBQ0ksZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSw4QkFBQTtFQUNBLCtCQUFBO0FDSEo7O0FETUE7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZ0JBQUE7QUNISjs7QURNQTtFQUNJLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSx5QkFBQTtBQ0hKOztBRE1BO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EseUJBQUE7QUNISjs7QURNQTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUNISjs7QURNQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQ0FBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBQ0hKOztBRE1BO0VBQ0kseUJBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGdDQUFBO0VBQ0EsMkJBQUE7RUFDQSxlQUFBO0FDSEo7O0FETUE7RUFDSSx1QkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLGNBQUE7QUNISjs7QURNQTtFQUNJLDhEQUFBO0FDSEo7O0FETUE7RUFDSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsNEJBQUE7QUNISjs7QURTSTtFQUNJLDZCQUFBO0VBQ0EsY0FBQTtBQ05SOztBRFVBO0VBQ0ksb0NBQUE7QUNQSjs7QURVQTtFQUNJLFlBQUE7QUNQSiIsImZpbGUiOiJzcmMvYXBwL2NvbXBvbmVudHMvaGVhZGVyL2hlYWRlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi50aXRsZSB7XHJcbiAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgZm9udC1mYW1pbHk6IEFyaWFsICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zdWItdGl0bGV7XHJcbiAgICBmb250LWZhbWlseTogXCJCcnVzaCBTY3JpcHQgTVRcIiAhaW1wb3J0YW50O1xyXG4gICAgY29sb3I6IHJnYig4MCwgODEsIDgxKTtcclxuICAgIGZvbnQtc2l6ZTogMTdweDtcclxufVxyXG5cclxuIG5hdntcclxuICAgICBtYXJnaW4tdG9wOiAtNzBweCAhaW1wb3J0YW50O1xyXG4gfVxyXG5cclxuLnUtbmF2LWl0ZW17XHJcbiAgICAvLyBtYXJnaW4tdG9wOiAxcmVtO1xyXG4gICAgLy8gbWFyZ2luLWJvdHRvbTogMXJlbTtcclxuICAgIG1hcmdpbi1sZWZ0OiAwLjhyZW07XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDAuOHJlbTtcclxuICAgIGJvcmRlci1ib3R0b206IHNvbGlkIDNweCB0cmFuc3BhcmVudDtcclxuICAgIGJvcmRlci10b3A6IG5vbmU7XHJcbiAgICBib3JkZXItbGVmdDogbm9uZTtcclxuICAgIGJvcmRlci1yaWdodDogbm9uZTtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDNweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAzcHg7XHJcbn1cclxuXHJcbkBtZWRpYSAobWluLXdpZHRoOiA5OTBweCl7XHJcbiAgICAuZm9yX21vYmlsZXtcclxuICAgICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAuZm9yX2Rlc2t0b3B7XHJcbiAgICAgICAgZGlzcGxheTogdW5zZXQgIWltcG9ydGFudDtcclxuICAgIH1cclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDk5MHB4KXtcclxuICAgIC5mb3JfZGVza3RvcHtcclxuICAgICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAudS1oZWFkZXIgLnUtaW1hZ2UtMSB7XHJcbiAgICAgICAgd2lkdGg6IDY0cHg7XHJcbiAgICAgICAgaGVpZ2h0OiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbjogdW5zZXQgIWltcG9ydGFudDtcclxuICAgICAgICAvKiBoZWlnaHQ6IDMycHg7ICovXHJcbiAgICB9XHJcbiAgICBsYWJlbHtcclxuICAgICAgICAvLyB0b3A6IC0xMHB4O1xyXG4gICAgfVxyXG4gICAgLmNvbC1zbS0xMntcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG59XHJcblxyXG4uYWN0aXZlX2xpbmt7XHJcbiAgICBib3JkZXItYm90dG9tOiBzb2xpZCAzcHggIzE5M2ViODtcclxuICAgIGJvcmRlci10b3A6IG5vbmU7XHJcbiAgICBib3JkZXItbGVmdDogbm9uZTtcclxuICAgIGJvcmRlci1yaWdodDogbm9uZTtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDNweDtcclxuICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAzcHg7XHJcbn1cclxuXHJcbi5jYXJke1xyXG4gICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgcGFkZGluZzogOHB4O1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgbWFyZ2luOiAxNXB4IDBweDtcclxufVxyXG5cclxuaW5wdXQsIHNlbGVjdCwgbWRiLXNlbGVjdC0ye1xyXG4gICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBoZWlnaHQ6IDQ1cHg7XHJcbiAgICBjb2xvcjogcmdiKDIwLCAyMCwgMjApICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbnRleHRhcmVhe1xyXG4gICAgcGFkZGluZzogOHB4IDE2cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgICBjb2xvcjogcmdiKDIwLCAyMCwgMjApICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5yb3d7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLm9wdGlvbnN7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIG1hcmdpbi1sZWZ0OiAwcHg7XHJcbiAgICBwYWRkaW5nOiA4cHggMTZweDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jayAhaW1wb3J0YW50O1xyXG4gICAgb3ZlcmZsb3cteDogaGlkZGVuICFpbXBvcnRhbnQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5vcHRpb25zOmhvdmVye1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzE5M2ViODtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDBweDtcclxuICAgIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrICFpbXBvcnRhbnQ7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuICFpbXBvcnRhbnQ7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5iZy13aGl0ZXtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MHB4O1xyXG4gICAgei1pbmRleDogOTk5OTk7XHJcbn0gICBcclxuXHJcbi5zaGFkb3dfMHtcclxuICAgIGJveC1zaGFkb3c6IDAgLjEyNXJlbSAuMjVyZW0gcmdiYSgwLDAsMCwuMDc1KSFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmxhYmVse1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMzBweDtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIGNvbG9yOiAjMTkzZWI4O1xyXG4gICAgcGFkZGluZzogMHB4IDhweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYigyNDUsIDI0NSwgMjQ1KTtcclxufVxyXG5cclxuLm1iLTV7XHJcbiAgICAvLyBtYXJnaW4tdG9wOiA4cHg7XHJcbiAgICAvLyBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbiAgICBzdmd7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAzMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6ICNhN2E3YTdcclxuICAgIH1cclxufVxyXG5cclxuLnBheV9idG57XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTkzZWI4ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmZvcm17XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbn0iLCIudGl0bGUge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGZvbnQtd2VpZ2h0OiA3MDA7XG4gIGZvbnQtZmFtaWx5OiBBcmlhbCAhaW1wb3J0YW50O1xufVxuXG4uc3ViLXRpdGxlIHtcbiAgZm9udC1mYW1pbHk6IFwiQnJ1c2ggU2NyaXB0IE1UXCIgIWltcG9ydGFudDtcbiAgY29sb3I6ICM1MDUxNTE7XG4gIGZvbnQtc2l6ZTogMTdweDtcbn1cblxubmF2IHtcbiAgbWFyZ2luLXRvcDogLTcwcHggIWltcG9ydGFudDtcbn1cblxuLnUtbmF2LWl0ZW0ge1xuICBtYXJnaW4tbGVmdDogMC44cmVtO1xuICBtYXJnaW4tcmlnaHQ6IDAuOHJlbTtcbiAgYm9yZGVyLWJvdHRvbTogc29saWQgM3B4IHRyYW5zcGFyZW50O1xuICBib3JkZXItdG9wOiBub25lO1xuICBib3JkZXItbGVmdDogbm9uZTtcbiAgYm9yZGVyLXJpZ2h0OiBub25lO1xuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiAzcHg7XG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAzcHg7XG59XG5cbkBtZWRpYSAobWluLXdpZHRoOiA5OTBweCkge1xuICAuZm9yX21vYmlsZSB7XG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLmZvcl9kZXNrdG9wIHtcbiAgICBkaXNwbGF5OiB1bnNldCAhaW1wb3J0YW50O1xuICB9XG59XG5AbWVkaWEgKG1heC13aWR0aDogOTkwcHgpIHtcbiAgLmZvcl9kZXNrdG9wIHtcbiAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XG4gIH1cblxuICAudS1oZWFkZXIgLnUtaW1hZ2UtMSB7XG4gICAgd2lkdGg6IDY0cHg7XG4gICAgaGVpZ2h0OiB1bnNldCAhaW1wb3J0YW50O1xuICAgIG1hcmdpbjogdW5zZXQgIWltcG9ydGFudDtcbiAgICAvKiBoZWlnaHQ6IDMycHg7ICovXG4gIH1cblxuICAuY29sLXNtLTEyIHtcbiAgICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luLWJvdHRvbTogMTBweCAhaW1wb3J0YW50O1xuICB9XG59XG4uYWN0aXZlX2xpbmsge1xuICBib3JkZXItYm90dG9tOiBzb2xpZCAzcHggIzE5M2ViODtcbiAgYm9yZGVyLXRvcDogbm9uZTtcbiAgYm9yZGVyLWxlZnQ6IG5vbmU7XG4gIGJvcmRlci1yaWdodDogbm9uZTtcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogM3B4O1xuICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogM3B4O1xufVxuXG4uY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgcGFkZGluZzogOHB4O1xuICBoZWlnaHQ6IGF1dG87XG4gIG1hcmdpbjogMTVweCAwcHg7XG59XG5cbmlucHV0LCBzZWxlY3QsIG1kYi1zZWxlY3QtMiB7XG4gIHBhZGRpbmc6IDhweCAxNnB4O1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiA1MDA7XG4gIGhlaWdodDogNDVweDtcbiAgY29sb3I6ICMxNDE0MTQgIWltcG9ydGFudDtcbn1cblxudGV4dGFyZWEge1xuICBwYWRkaW5nOiA4cHggMTZweDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogNTAwO1xuICBjb2xvcjogIzE0MTQxNCAhaW1wb3J0YW50O1xufVxuXG4ucm93IHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcbn1cblxuLm9wdGlvbnMge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBmb250LXNpemU6IDE2cHg7XG4gIG1hcmdpbi1sZWZ0OiAwcHg7XG4gIHBhZGRpbmc6IDhweCAxNnB4O1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcbiAgb3ZlcmZsb3cteDogaGlkZGVuICFpbXBvcnRhbnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLm9wdGlvbnM6aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMTkzZWI4O1xuICBjb2xvcjogd2hpdGU7XG4gIGhlaWdodDogNDBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbWFyZ2luLWxlZnQ6IDBweDtcbiAgcGFkZGluZzogOHB4IDE2cHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jayAhaW1wb3J0YW50O1xuICBvdmVyZmxvdzogaGlkZGVuICFpbXBvcnRhbnQ7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLmJnLXdoaXRlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiA1MHB4O1xuICB6LWluZGV4OiA5OTk5OTtcbn1cblxuLnNoYWRvd18wIHtcbiAgYm94LXNoYWRvdzogMCAwLjEyNXJlbSAwLjI1cmVtIHJnYmEoMCwgMCwgMCwgMC4wNzUpICFpbXBvcnRhbnQ7XG59XG5cbmxhYmVsIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAzMHB4O1xuICBmb250LXNpemU6IDEycHg7XG4gIGNvbG9yOiAjMTkzZWI4O1xuICBwYWRkaW5nOiAwcHggOHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZXNtb2tlO1xufVxuXG4ubWItNSBzdmcge1xuICBtYXJnaW4tcmlnaHQ6IDMwcHggIWltcG9ydGFudDtcbiAgY29sb3I6ICNhN2E3YTc7XG59XG5cbi5wYXlfYnRuIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzE5M2ViOCAhaW1wb3J0YW50O1xufVxuXG5mb3JtIHtcbiAgYm9yZGVyOiBub25lO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/components/header/header.component.ts":
/*!*******************************************************!*\
  !*** ./src/app/components/header/header.component.ts ***!
  \*******************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_maps_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/maps.service */ "./src/app/services/maps.service.ts");
/* harmony import */ var _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/fire/auth */ "./node_modules/@angular/fire/fesm2015/angular-fire-auth.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js");
/* harmony import */ var src_app_services_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/services/api.service */ "./src/app/services/api.service.ts");
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/services/modal.service */ "./src/app/services/modal.service.ts");



// import { Common } from '../../providers/common';




let HeaderComponent = class HeaderComponent {
    constructor(zone, 
    // public common: Common,
    afa, afs, maps, api, modal) {
        this.zone = zone;
        this.afa = afa;
        this.afs = afs;
        this.maps = maps;
        this.api = api;
        this.modal = modal;
        this.loading = false;
        this.autocomplete = { input: '', lat: '', lng: '' };
        this.pickupcomplete = { input: '', lat: '', lng: '' };
        this.dropcomplete = { input: '', lat: '', lng: '' };
        this.pickupautocompleteItems = [];
        this.dropautocompleteItems = [];
        this.current_lat = 0;
        this.current_lng = 0;
        this.categories = [];
        this.date_of_delivery = new Date().toISOString().split('T')[0].toString();
        this.reference = Math.random().toString(36).substr(2, 10);
        this.height = 0;
        this.width = 0;
    }
    ngOnInit() {
        this.afa.authState.subscribe(res => {
            this.user = res;
            this.getUserProfile();
        });
        this.api.getRatePerKm().valueChanges().subscribe(res => {
            this.rate = res;
            console.log(this.rate);
        });
        this.modal.setModal(this.basicModal);
    }
    ngAfterViewInit() {
        this.api.getAllCategories().valueChanges().subscribe(ref => {
            this.categories = ref;
            console.log(this.categories);
        });
        setTimeout(() => {
            this.maps.init(this.elemElem.nativeElement).then(() => {
                this.autocompleteService = new google.maps.places.AutocompleteService();
                this.placesService = new google.maps.places.PlacesService();
            });
        }, 500);
    }
    getUserProfile() {
        this.api.getUserProfile(this.user.uid).valueChanges().subscribe(ref => {
            this.singleUser = ref;
            if (this.singleUser) {
                this.email = this.singleUser.email;
                this.firstname = this.singleUser.firstname;
                this.lastname = this.singleUser.lastname;
                this.phone = this.singleUser.phone;
            }
        });
    }
    updateSearchResults() {
        if (this.autocomplete.input == '') {
            this.autocompleteItems = [];
            return;
        }
        let location = {
            lat: this.current_lat,
            lng: this.current_lng,
        };
        let config = {
            input: this.autocomplete.input
        };
        this.autocompleteService.getPlacePredictions(config, (predictions, status) => {
            console.log(status);
            this.autocompleteItems = [];
            this.zone.run(() => {
                predictions.forEach((prediction) => {
                    this.autocompleteItems.push(prediction);
                });
            });
        });
    }
    pickupSearchResults(input) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (input == '') {
                this.pickupautocompleteItems = [];
                return;
            }
            console.log(input);
            let location = {
                lat: this.current_lat,
                lng: this.current_lng,
            };
            let config = {
                bounds: new google.maps.LatLngBounds(location),
                input: input
            };
            this.autocompleteService = yield new google.maps.places.AutocompleteService();
            this.autocompleteService.getPlacePredictions(config, (predictions, status) => {
                console.log(status);
                this.pickupautocompleteItems = [];
                this.zone.run(() => {
                    predictions.forEach((prediction) => {
                        this.pickupautocompleteItems.push(prediction);
                    });
                    setTimeout(() => {
                        console.log(this.pickupautocompleteItems);
                    }, 1000);
                });
            });
        });
    }
    selectPickupLocation(location) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.pickup_location = yield location;
            console.log(location);
            if (location.description) {
                this.pickupcomplete.input = yield location.description;
                setTimeout(() => {
                    this.pickupautocompleteItems = [];
                }, 200);
                this.placesService = yield new google.maps.places.PlacesService(this.maps.map);
                yield this.placesService.getDetails({ placeId: location.place_id }, (details) => {
                    this.zone.run(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                        this.pickupcomplete.lat = yield details.geometry.location.lat();
                        this.pickupcomplete.lng = yield details.geometry.location.lng();
                    }));
                    console.log(this.pickupcomplete);
                });
            }
        });
    }
    dropSearchResults(input) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            if (input == '') {
                this.dropautocompleteItems = [];
                return;
            }
            console.log(input);
            let location = {
                lat: this.current_lat,
                lng: this.current_lng,
            };
            let config = {
                bounds: new google.maps.LatLngBounds(location),
                input: input
            };
            this.autocompleteService = yield new google.maps.places.AutocompleteService();
            this.autocompleteService.getPlacePredictions(config, (predictions, status) => {
                console.log(status);
                this.dropautocompleteItems = [];
                this.zone.run(() => {
                    predictions.forEach((prediction) => {
                        this.dropautocompleteItems.push(prediction);
                    });
                    setTimeout(() => {
                        console.log(this.dropautocompleteItems);
                    }, 1000);
                });
            });
        });
    }
    selectDropLocation(location) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // let location = await this.dropcomplete;
            console.log(location);
            if (location.description) {
                this.dropcomplete.input = yield location.description;
                setTimeout(() => {
                    this.dropautocompleteItems = [];
                }, 200);
                this.placesService.getDetails({ placeId: location.place_id }, (details) => {
                    this.zone.run(() => {
                        this.dropcomplete.lat = details.geometry.location.lat();
                        this.dropcomplete.lng = details.geometry.location.lng();
                    });
                    console.log(this.dropcomplete);
                });
                this.placesService.getDetails({ placeId: location.place_id }, (details) => {
                    this.zone.run(() => {
                        this.dropcomplete.lat = details.geometry.location.lat();
                        this.dropcomplete.lng = details.geometry.location.lng();
                    });
                    console.log(this.dropcomplete);
                });
            }
        });
    }
    continue(uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone, date_of_delivery, desc) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            console.log(uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone, date_of_delivery, desc);
            if (email && firstname && lastname && category && pickupcomplete && dropcomplete && phone && date_of_delivery && desc) {
                if (uid) {
                    this.saveData(uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone, desc);
                }
                else {
                    this.signUpUser().then(() => {
                        this.saveData(this.user.uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone, desc);
                    });
                }
            }
            else {
                alert('Kindly ensure you fill all fields');
            }
        });
    }
    signUpUser() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.afa.signInAnonymously().then(res => {
                this.user = res.user;
                console.log(this.user);
            });
        });
    }
    saveData(uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone, desc) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading = yield true;
            console.log(uid, email, firstname, lastname, height, width, category, pickupcomplete, dropcomplete, phone);
            yield this.api.getUserProfile(uid).set({
                uid: uid, firstname: firstname, lastname: lastname, email: email, phone: phone, date: new Date().getTime()
            }).then(() => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                yield this.calcRoute().then(() => {
                    setTimeout(() => {
                        this.launchPayment();
                        this.singleUser = {
                            firstname: firstname,
                            lastname: lastname,
                            phone: phone,
                            email: email,
                            uid: this.user.uid
                        };
                    }, 6000);
                });
                console.log(this.pickupcomplete, this.dropcomplete);
            }));
        });
    }
    calcRoute() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            var request = {
                origin: { lat: parseFloat(yield this.pickupcomplete.lat), lng: parseFloat(yield this.pickupcomplete.lng) },
                destination: { lat: parseFloat(yield this.dropcomplete.lat), lng: parseFloat(yield this.dropcomplete.lng) },
                travelMode: google.maps.DirectionsTravelMode.DRIVING,
                unitSystem: google.maps.UnitSystem.METRIC
            };
            console.log(request);
            this.directionsService = new google.maps.DirectionsService;
            this.directionsService.route(request, ((response, status) => tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
                console.log("calculate");
                if (status == google.maps.DirectionsStatus.OK) {
                    new google.maps.DirectionsRenderer({
                        map: yield this.maps.map,
                        directions: response,
                        suppressMarkers: true
                    });
                    var leg = yield response.routes[0].legs[0];
                    console.log('response legs', response);
                    this.trip_distance = (yield response.routes[0].legs[0].distance.value) / 1000;
                    this.trip_distance = Math.ceil((yield this.trip_distance) * 10) / 10;
                    this.amount = Math.round(this.trip_distance) * this.rate.rate;
                    console.log(this.trip_distance);
                    console.log(this.amount);
                }
            })), err => {
                console.log("ERROR!: ", err);
            });
        });
    }
    launchPayment() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.loading = yield false;
            this.basicModal.hide();
            this.paymentModal.show();
        });
    }
    closeBtn() {
        document.getElementById("close_btn").click();
    }
    paymentInit() {
        console.log('Payment initialized');
    }
    paymentCancel() {
        console.log('payment failed');
    }
    paymentDone(evt) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let order_id = yield this.afs.createId();
            let pay_id = yield this.afs.createId();
            if (evt) {
                let order_details = yield {
                    drop_location: this.dropcomplete,
                    pickup_location: this.pickupcomplete,
                    category: this.selected_category,
                    description: this.desc,
                    date_of_delivery: this.date_of_delivery,
                    package_height: this.height,
                    package_width: this.width,
                };
                //save payment
                yield this.api.getPayment(yield pay_id).set({
                    id: yield pay_id,
                    amount: this.amount,
                    ref: this.reference,
                    user_details: this.singleUser,
                    order_details: order_details,
                    date: new Date().getTime()
                });
                //save successful order
                yield this.api.getOrder(yield order_id).set({
                    id: yield order_id,
                    paid: true,
                    payment_id: yield pay_id,
                    amount_paid: this.amount,
                    payment_ref: this.reference,
                    user_details: this.singleUser,
                    order_details: order_details,
                    date: new Date().getTime()
                });
                setTimeout(() => {
                    alert('Payment Successful, Our agent will give you a call shortlu');
                    this.paymentModal.hide();
                    setTimeout(() => {
                        window.location.reload();
                    }, 1000);
                }, 300);
            }
        });
    }
};
HeaderComponent.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["NgZone"] },
    { type: _angular_fire_auth__WEBPACK_IMPORTED_MODULE_3__["AngularFireAuth"] },
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_4__["AngularFirestore"] },
    { type: _services_maps_service__WEBPACK_IMPORTED_MODULE_2__["MapsService"] },
    { type: src_app_services_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"] },
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_6__["ModalService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("basicModal", { static: true })
], HeaderComponent.prototype, "basicModal", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("paymentModal", { static: false })
], HeaderComponent.prototype, "paymentModal", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('map_canvas', { static: true })
], HeaderComponent.prototype, "elemElem", void 0);
HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-header',
        template: __webpack_require__(/*! raw-loader!./header.component.html */ "./node_modules/raw-loader/index.js!./src/app/components/header/header.component.html"),
        styles: [__webpack_require__(/*! ./header.component.scss */ "./src/app/components/header/header.component.scss")]
    })
], HeaderComponent);



/***/ }),

/***/ "./src/app/pages/about/about.component.scss":
/*!**************************************************!*\
  !*** ./src/app/pages/about/about.component.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".u-text-2 {\n  color: #515151;\n  line-height: 30px;\n}\n\n@media (min-width: 767px) {\n  .u-shape-1 {\n    padding: unset !important;\n    margin: unset !important;\n    right: 0px !important;\n    top: 20rem;\n  }\n\n  .u-shape-2 {\n    padding: unset !important;\n    margin: unset !important;\n    left: 10rem !important;\n    z-index: -10;\n    top: 20rem;\n  }\n\n  .u-section-3 .u-list-1 {\n    min-height: 275px;\n    grid-template-columns: repeat(3, calc(33% - 23px)) !important;\n    grid-template-rows: repeat(1, auto);\n    grid-gap: 30px;\n    margin: 30px auto 60px 0;\n  }\n}\n\n@media (max-width: 767px) {\n  .u-shape-1 {\n    display: none !important;\n  }\n\n  .u-shape-2 {\n    display: none !important;\n  }\n\n  .u-section-3 .u-list-1 {\n    min-height: 275px;\n    grid-template-columns: repeat(1, calc(100% - 23px)) !important;\n    grid-template-rows: repeat(1, auto);\n    grid-gap: 30px;\n    margin: 30px auto 60px 0;\n  }\n}\n\n.u-align-center {\n  margin: auto !important;\n}\n\n.u-container-style {\n  margin: auto !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvYWJvdXQvQzpcXFVzZXJzXFxIUFxcRGVza3RvcFxcTVkgUFJPSkVDVFNcXFN0cmVldHdpc2Uvc3JjXFxhcHBcXHBhZ2VzXFxhYm91dFxcYWJvdXQuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2Fib3V0L2Fib3V0LmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0FDQ0o7O0FERUE7RUFDSTtJQUNJLHlCQUFBO0lBQ0Esd0JBQUE7SUFDQSxxQkFBQTtJQUNBLFVBQUE7RUNDTjs7RURDRTtJQUNJLHlCQUFBO0lBQ0Esd0JBQUE7SUFDQSxzQkFBQTtJQUNBLFlBQUE7SUFDQSxVQUFBO0VDRU47O0VEQ0U7SUFDSSxpQkFBQTtJQUNBLDZEQUFBO0lBQ0EsbUNBQUE7SUFDQSxjQUFBO0lBQ0Esd0JBQUE7RUNFTjtBQUNGOztBRENBO0VBQ0k7SUFDSSx3QkFBQTtFQ0NOOztFRENFO0lBQ0ksd0JBQUE7RUNFTjs7RURBRTtJQUNJLGlCQUFBO0lBQ0EsOERBQUE7SUFDQSxtQ0FBQTtJQUNBLGNBQUE7SUFDQSx3QkFBQTtFQ0dOO0FBQ0Y7O0FEQ0E7RUFDSSx1QkFBQTtBQ0NKOztBREVBO0VBQ0ksdUJBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2Fib3V0L2Fib3V0LmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnUtdGV4dC0ye1xyXG4gICAgY29sb3I6IHJnYig4MSwgODEsIDgxKTtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogNzY3cHgpe1xyXG4gICAgLnUtc2hhcGUtMXtcclxuICAgICAgICBwYWRkaW5nOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbjogdW5zZXQgIWltcG9ydGFudDtcclxuICAgICAgICByaWdodDogMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgdG9wOiAyMHJlbTtcclxuICAgIH1cclxuICAgIC51LXNoYXBlLTIge1xyXG4gICAgICAgIHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgbWFyZ2luOiB1bnNldCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGxlZnQ6IDEwcmVtICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgei1pbmRleDogLTEwO1xyXG4gICAgICAgIHRvcDogMjByZW07XHJcbiAgICB9XHJcblxyXG4gICAgLnUtc2VjdGlvbi0zIC51LWxpc3QtMSB7XHJcbiAgICAgICAgbWluLWhlaWdodDogMjc1cHg7XHJcbiAgICAgICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMywgY2FsYygzMyUgLSAyM3B4KSkgIWltcG9ydGFudDtcclxuICAgICAgICBncmlkLXRlbXBsYXRlLXJvd3M6IHJlcGVhdCgxLCBhdXRvKTtcclxuICAgICAgICBncmlkLWdhcDogMzBweDtcclxuICAgICAgICBtYXJnaW46IDMwcHggYXV0byA2MHB4IDA7XHJcbiAgICAgIH1cclxufVxyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDc2N3B4KXtcclxuICAgIC51LXNoYXBlLTF7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLnUtc2hhcGUtMntcclxuICAgICAgICBkaXNwbGF5OiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAudS1zZWN0aW9uLTMgLnUtbGlzdC0xIHtcclxuICAgICAgICBtaW4taGVpZ2h0OiAyNzVweDtcclxuICAgICAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IHJlcGVhdCgxLCBjYWxjKDEwMCUgLSAyM3B4KSkgIWltcG9ydGFudDtcclxuICAgICAgICBncmlkLXRlbXBsYXRlLXJvd3M6IHJlcGVhdCgxLCBhdXRvKTtcclxuICAgICAgICBncmlkLWdhcDogMzBweDtcclxuICAgICAgICBtYXJnaW46IDMwcHggYXV0byA2MHB4IDA7XHJcbiAgICAgIH1cclxufVxyXG5cclxuXHJcbi51LWFsaWduLWNlbnRlcntcclxuICAgIG1hcmdpbjogYXV0byAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udS1jb250YWluZXItc3R5bGV7XHJcbiAgICBtYXJnaW46IGF1dG8gIWltcG9ydGFudDtcclxufSIsIi51LXRleHQtMiB7XG4gIGNvbG9yOiAjNTE1MTUxO1xuICBsaW5lLWhlaWdodDogMzBweDtcbn1cblxuQG1lZGlhIChtaW4td2lkdGg6IDc2N3B4KSB7XG4gIC51LXNoYXBlLTEge1xuICAgIHBhZGRpbmc6IHVuc2V0ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiB1bnNldCAhaW1wb3J0YW50O1xuICAgIHJpZ2h0OiAwcHggIWltcG9ydGFudDtcbiAgICB0b3A6IDIwcmVtO1xuICB9XG5cbiAgLnUtc2hhcGUtMiB7XG4gICAgcGFkZGluZzogdW5zZXQgIWltcG9ydGFudDtcbiAgICBtYXJnaW46IHVuc2V0ICFpbXBvcnRhbnQ7XG4gICAgbGVmdDogMTByZW0gIWltcG9ydGFudDtcbiAgICB6LWluZGV4OiAtMTA7XG4gICAgdG9wOiAyMHJlbTtcbiAgfVxuXG4gIC51LXNlY3Rpb24tMyAudS1saXN0LTEge1xuICAgIG1pbi1oZWlnaHQ6IDI3NXB4O1xuICAgIGdyaWQtdGVtcGxhdGUtY29sdW1uczogcmVwZWF0KDMsIGNhbGMoMzMlIC0gMjNweCkpICFpbXBvcnRhbnQ7XG4gICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiByZXBlYXQoMSwgYXV0byk7XG4gICAgZ3JpZC1nYXA6IDMwcHg7XG4gICAgbWFyZ2luOiAzMHB4IGF1dG8gNjBweCAwO1xuICB9XG59XG5AbWVkaWEgKG1heC13aWR0aDogNzY3cHgpIHtcbiAgLnUtc2hhcGUtMSB7XG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnUtc2hhcGUtMiB7XG4gICAgZGlzcGxheTogbm9uZSAhaW1wb3J0YW50O1xuICB9XG5cbiAgLnUtc2VjdGlvbi0zIC51LWxpc3QtMSB7XG4gICAgbWluLWhlaWdodDogMjc1cHg7XG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiByZXBlYXQoMSwgY2FsYygxMDAlIC0gMjNweCkpICFpbXBvcnRhbnQ7XG4gICAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiByZXBlYXQoMSwgYXV0byk7XG4gICAgZ3JpZC1nYXA6IDMwcHg7XG4gICAgbWFyZ2luOiAzMHB4IGF1dG8gNjBweCAwO1xuICB9XG59XG4udS1hbGlnbi1jZW50ZXIge1xuICBtYXJnaW46IGF1dG8gIWltcG9ydGFudDtcbn1cblxuLnUtY29udGFpbmVyLXN0eWxlIHtcbiAgbWFyZ2luOiBhdXRvICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/about/about.component.ts":
/*!************************************************!*\
  !*** ./src/app/pages/about/about.component.ts ***!
  \************************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AboutComponent = class AboutComponent {
    constructor() { }
    ngOnInit() {
    }
};
AboutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-about',
        template: __webpack_require__(/*! raw-loader!./about.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/about/about.component.html"),
        styles: [__webpack_require__(/*! ./about.component.scss */ "./src/app/pages/about/about.component.scss")]
    })
], AboutComponent);



/***/ }),

/***/ "./src/app/pages/contact/contact.component.scss":
/*!******************************************************!*\
  !*** ./src/app/pages/contact/contact.component.scss ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".map_embed {\n  height: 500px;\n  width: 100%;\n  margin-top: 3rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvY29udGFjdC9DOlxcVXNlcnNcXEhQXFxEZXNrdG9wXFxNWSBQUk9KRUNUU1xcU3RyZWV0d2lzZS9zcmNcXGFwcFxccGFnZXNcXGNvbnRhY3RcXGNvbnRhY3QuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2NvbnRhY3QvY29udGFjdC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2NvbnRhY3QvY29udGFjdC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYXBfZW1iZWR7XHJcbiAgICBoZWlnaHQ6IDUwMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAzcmVtO1xyXG59IiwiLm1hcF9lbWJlZCB7XG4gIGhlaWdodDogNTAwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBtYXJnaW4tdG9wOiAzcmVtO1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/pages/contact/contact.component.ts":
/*!****************************************************!*\
  !*** ./src/app/pages/contact/contact.component.ts ***!
  \****************************************************/
/*! exports provided: ContactComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactComponent", function() { return ContactComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ContactComponent = class ContactComponent {
    constructor() { }
    ngOnInit() {
    }
};
ContactComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-contact',
        template: __webpack_require__(/*! raw-loader!./contact.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/contact/contact.component.html"),
        styles: [__webpack_require__(/*! ./contact.component.scss */ "./src/app/pages/contact/contact.component.scss")]
    })
], ContactComponent);



/***/ }),

/***/ "./src/app/pages/faq/faq.component.scss":
/*!**********************************************!*\
  !*** ./src/app/pages/faq/faq.component.scss ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".card {\n  border-radius: 5px;\n  padding: 8px 16px;\n  height: 200px;\n  margin: 15px 0px;\n  overflow-y: scroll;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvZmFxL0M6XFxVc2Vyc1xcSFBcXERlc2t0b3BcXE1ZIFBST0pFQ1RTXFxTdHJlZXR3aXNlL3NyY1xcYXBwXFxwYWdlc1xcZmFxXFxmYXEuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2ZhcS9mYXEuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUNDSiIsImZpbGUiOiJzcmMvYXBwL3BhZ2VzL2ZhcS9mYXEuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY2FyZHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHBhZGRpbmc6IDhweCAxNnB4O1xyXG4gICAgaGVpZ2h0OiAyMDBweDtcclxuICAgIG1hcmdpbjogMTVweCAwcHg7XHJcbiAgICBvdmVyZmxvdy15OiBzY3JvbGw7XHJcbn0iLCIuY2FyZCB7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgcGFkZGluZzogOHB4IDE2cHg7XG4gIGhlaWdodDogMjAwcHg7XG4gIG1hcmdpbjogMTVweCAwcHg7XG4gIG92ZXJmbG93LXk6IHNjcm9sbDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/pages/faq/faq.component.ts":
/*!********************************************!*\
  !*** ./src/app/pages/faq/faq.component.ts ***!
  \********************************************/
/*! exports provided: FaqComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FaqComponent", function() { return FaqComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let FaqComponent = class FaqComponent {
    constructor() { }
    ngOnInit() {
    }
};
FaqComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-faq',
        template: __webpack_require__(/*! raw-loader!./faq.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/faq/faq.component.html"),
        styles: [__webpack_require__(/*! ./faq.component.scss */ "./src/app/pages/faq/faq.component.scss")]
    })
], FaqComponent);



/***/ }),

/***/ "./src/app/pages/home/home.component.scss":
/*!************************************************!*\
  !*** ./src/app/pages/home/home.component.scss ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@media (min-width: 580px) {\n  .my_bg {\n    background-image: url(\"https://www.coscourier.com/ressources/images/1cfc9ac52211.jpg\");\n    background-repeat: no-repeat;\n    background-size: cover;\n    background-position: center;\n  }\n}\n@media (max-width: 580px) {\n  .my_bg {\n    display: none;\n  }\n\n  .u-section-5 {\n    max-height: 1200px !important;\n    margin: unset !important;\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGFnZXMvaG9tZS9DOlxcVXNlcnNcXEhQXFxEZXNrdG9wXFxNWSBQUk9KRUNUU1xcU3RyZWV0d2lzZS9zcmNcXGFwcFxccGFnZXNcXGhvbWVcXGhvbWUuY29tcG9uZW50LnNjc3MiLCJzcmMvYXBwL3BhZ2VzL2hvbWUvaG9tZS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQTtFQUNJO0lBQ0ksc0ZBQUE7SUFDQSw0QkFBQTtJQUNBLHNCQUFBO0lBQ0EsMkJBQUE7RUNGTjtBQUNGO0FES0E7RUFDSTtJQUNJLGFBQUE7RUNITjs7RURNRTtJQUNJLDZCQUFBO0lBQ0Esd0JBQUE7RUNITjtBQUNGIiwiZmlsZSI6InNyYy9hcHAvcGFnZXMvaG9tZS9ob21lLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcblxyXG5cclxuQG1lZGlhIChtaW4td2lkdGg6IDU4MHB4KXtcclxuICAgIC5teV9iZ3tcclxuICAgICAgICBiYWNrZ3JvdW5kLWltYWdlOiB1cmwoJ2h0dHBzOi8vd3d3LmNvc2NvdXJpZXIuY29tL3Jlc3NvdXJjZXMvaW1hZ2VzLzFjZmM5YWM1MjIxMS5qcGcnKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICAgIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcbiAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG4gICAgfVxyXG59XHJcblxyXG5AbWVkaWEgKG1heC13aWR0aDogNTgwcHgpe1xyXG4gICAgLm15X2Jne1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICB9XHJcblxyXG4gICAgLnUtc2VjdGlvbi01e1xyXG4gICAgICAgIG1heC1oZWlnaHQ6IDEyMDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIG1hcmdpbjogdW5zZXQgIWltcG9ydGFudDtcclxuICAgIH1cclxufSIsIkBtZWRpYSAobWluLXdpZHRoOiA1ODBweCkge1xuICAubXlfYmcge1xuICAgIGJhY2tncm91bmQtaW1hZ2U6IHVybChcImh0dHBzOi8vd3d3LmNvc2NvdXJpZXIuY29tL3Jlc3NvdXJjZXMvaW1hZ2VzLzFjZmM5YWM1MjIxMS5qcGdcIik7XG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xuICAgIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlcjtcbiAgfVxufVxuQG1lZGlhIChtYXgtd2lkdGg6IDU4MHB4KSB7XG4gIC5teV9iZyB7XG4gICAgZGlzcGxheTogbm9uZTtcbiAgfVxuXG4gIC51LXNlY3Rpb24tNSB7XG4gICAgbWF4LWhlaWdodDogMTIwMHB4ICFpbXBvcnRhbnQ7XG4gICAgbWFyZ2luOiB1bnNldCAhaW1wb3J0YW50O1xuICB9XG59Il19 */"

/***/ }),

/***/ "./src/app/pages/home/home.component.ts":
/*!**********************************************!*\
  !*** ./src/app/pages/home/home.component.ts ***!
  \**********************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/modal.service */ "./src/app/services/modal.service.ts");



let HomeComponent = class HomeComponent {
    constructor(modal) {
        this.modal = modal;
    }
    ngOnInit() {
    }
    showModal() {
        this.modal.showModal();
    }
};
HomeComponent.ctorParameters = () => [
    { type: src_app_services_modal_service__WEBPACK_IMPORTED_MODULE_2__["ModalService"] }
];
HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: __webpack_require__(/*! raw-loader!./home.component.html */ "./node_modules/raw-loader/index.js!./src/app/pages/home/home.component.html"),
        styles: [__webpack_require__(/*! ./home.component.scss */ "./src/app/pages/home/home.component.scss")]
    })
], HomeComponent);



/***/ }),

/***/ "./src/app/services/api.service.ts":
/*!*****************************************!*\
  !*** ./src/app/services/api.service.ts ***!
  \*****************************************/
/*! exports provided: ApiService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ApiService", function() { return ApiService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/fire/firestore */ "./node_modules/@angular/fire/fesm2015/angular-fire-firestore.js");



let ApiService = class ApiService {
    constructor(afs
    // public shared: SharedService
    ) {
        this.afs = afs;
    }
    getAllCategories() {
        return this.afs.collection('categories');
    }
    getRatePerKm() {
        return this.afs.collection('rates').doc('rate_per_km');
    }
    getUserProfile(uid) {
        return this.afs.collection('users').doc(uid);
    }
    getPayment(id) {
        return this.afs.collection('payments').doc(id);
    }
    getOrder(id) {
        return this.afs.collection('orders').doc(id);
    }
    getContact(id) {
        return this.afs.collection('contacts').doc(id);
    }
};
ApiService.ctorParameters = () => [
    { type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_2__["AngularFirestore"] }
];
ApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ApiService);



/***/ }),

/***/ "./src/app/services/maps.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/maps.service.ts ***!
  \******************************************/
/*! exports provided: MapsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MapsService", function() { return MapsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let MapsService = class MapsService {
    constructor() {
        this.mapInitialised = false;
        // apiKey: string =  "AIzaSyB1DSf-PRIb0k0bX9CAqDxLc0EHtAUCuPk";
        this.apiKey = 'AIzaSyDo_9F73WMtinAm7Mq-wXscn9WPz8AcAXM';
    }
    init(mapElement) {
        this.mapElement = mapElement;
        return this.loadGoogleMaps();
    }
    loadGoogleMaps() {
        this.mapInitialised = true;
        return new Promise((resolve) => {
            if (typeof google == "undefined" || typeof google.maps == "undefined") {
                console.log("Google maps JavaScript needs to be loaded.");
                window['mapInit'] = () => {
                    this.initMap().then(() => {
                        resolve(true);
                    });
                };
                let script = document.createElement("script");
                script.id = "googleMaps";
                if (this.apiKey) {
                    script.src = 'https://maps.google.com/maps/api/js?key=' + this.apiKey + '&callback=mapInit&libraries=places';
                }
                else {
                    script.src = 'https://maps.google.com/maps/api/js?callback=mapInit&libraries=places';
                }
                document.body.appendChild(script);
                resolve(true);
            }
        });
    }
    initMap() {
        this.mapInitialised = true;
        return new Promise((resolve) => {
            this.map = new google.maps.Map(this.mapElement);
            resolve(true);
        });
    }
    enableMap() {
        if (this.pleaseConnect) {
            this.pleaseConnect.style.display = "none";
        }
    }
};
MapsService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root' // <- ADD THIS
    })
], MapsService);



/***/ }),

/***/ "./src/app/services/modal.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/modal.service.ts ***!
  \*******************************************/
/*! exports provided: ModalService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ModalService", function() { return ModalService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ModalService = class ModalService {
    constructor() { }
    setModal(modal) {
        this.basicModal = modal;
    }
    showModal() {
        this.basicModal.show();
    }
    hideModal() {
        this.basicModal.hide();
    }
};
ModalService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ModalService);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    config: {
        apiKey: "AIzaSyB6wM4eX-uixvxRfsz0HB3vbhTWls3cKQ4",
        authDomain: "streetwise-delivery.firebaseapp.com",
        projectId: "streetwise-delivery",
        storageBucket: "streetwise-delivery.appspot.com",
        messagingSenderId: "847888751511",
        appId: "1:847888751511:web:e62d443db43dfac85042d2",
        measurementId: "G-GGEDJVWWCN"
    }
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.error(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\HP\Desktop\MY PROJECTS\Streetwise\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map